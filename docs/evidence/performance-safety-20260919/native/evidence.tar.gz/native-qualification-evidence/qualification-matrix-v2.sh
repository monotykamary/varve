#!/bin/bash
set -uo pipefail
e=/workspace/varve-rebuild/performance-safety-20260919/native-qualification-evidence
check() {
  bash --noprofile --norc "$e/qualify-command-v3.sh" "$@"
  rc=$?
  printf '%s %s\n' "$1" "$rc" >> "$e/matrix-v2.results"
}
check 13-final-native-default cargo test --locked --offline -p varve-storage --lib query::native -- --test-threads=1
check 14-final-integrations-fault cargo test --locked --offline -p varve-storage --features fault-injection --test rebuilt_engine --test query --test query_boundary --test query_catalog_exposure --test query_projection --test query_residency --test query_security --test query_typed_inputs --test query_workers --test model --test residency --test raw_pressure --test resident_pruning --test service --test transports -- --test-threads=1
check 15-final-native-fault cargo test --locked --offline -p varve-storage --lib --features fault-injection query::native -- --test-threads=1
check 16-final-clippy-default cargo clippy --locked --offline --workspace --all-targets -- -D warnings
check 17-final-clippy-fault cargo clippy --locked --offline --workspace --all-targets --features fault-injection -- -D warnings
check 18-final-fmt cargo fmt --all -- --check
cat "$e/matrix-v2.results"

#!/bin/bash
set -euo pipefail
base=/workspace/varve-rebuild/performance-safety-20260919
source_root="$base/native-qualification"
e="$base/native-qualification-evidence"
export PATH=/root/.cargo/bin:/workspace/varve-rebuild/baseline/.tools:$PATH
export CARGO_TARGET_DIR=/workspace/varve-rebuild/target CARGO_BUILD_JOBS=2
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_DEV_INCREMENTAL=false
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_INCREMENTAL=false
export VARVE_DUCKDB_CLI=/workspace/varve-rebuild/baseline/.tools/duckdb
export VARVE_DUCKDB_V2_LIBRARY=/workspace/varve-rebuild/baseline/.tools/duckdb-native-v2.0.0-alpha41533-linux-amd64/libduckdb.so
exec 9>/workspace/varve-rebuild/cargo-owner.lock
flock -n 9 || { echo 'Another Cargo owner is active'; exit 90; }
printf 'supervisor_pid=%s\nsource_root=%s\n' "$$" "$source_root" > "$e/owner-v1.txt"
trap 'printf "supervisor_exit=%s\n" "$?" >> "$e/owner-v1.txt"' EXIT
{
  rustc --version; cargo --version
  env | LC_ALL=C sort | grep -E '^(CARGO_(TARGET_DIR|BUILD_JOBS|PROFILE_)|VARVE_DUCKDB_|PATH=)'
  printf 'features=default (no --features)\n'
} > "$e/runtime-environment-v1.txt"
gate() (
  name=$1; phase=$2
  cd "$source_root"
  test "$(sha256sum "$e/source-files.sha256" | cut -c1-64)" = 6bb9ae816d7c585b459735f069817eb37609b1932e80b77b593db86361b7da7a
  test "$(sha256sum "$e/owned-files.sha256" | cut -c1-64)" = 06b572241f8caef445645648b51c174db33ed8169d3d4ffd4ef82d3b276611b6
  sha256sum -c "$e/source-files.sha256"
  sha256sum -c "$e/owned-files.sha256"
  test ! -L .tools
  test "$(find . -type l -print)" = ./.tools/duckdb
  test "$(readlink .tools/duckdb)" = "$VARVE_DUCKDB_CLI"
  test "$(sha256sum .tools/duckdb | cut -c1-64)" = 1dd0a1596505613a439dced4fb5f5800471badec82b2dc3b2c0efbd46fafbf6d
  test "$(sha256sum "$VARVE_DUCKDB_V2_LIBRARY" | cut -c1-64)" = 69bdd44e0d2426e7ba44ed14644b54d8bd99a9703e5cbb4aec3f8beef40f817d
  printf '.tools/duckdb -> %s\n' "$(readlink .tools/duckdb)"
  sha256sum .tools/duckdb "$VARVE_DUCKDB_V2_LIBRARY"
  find . -type f -printf '%P\n' | LC_ALL=C sort > "$e/$name.paths-$phase.txt"
  diff -u "$e/source-files132.txt" "$e/$name.paths-$phase.txt"
  test -z "$(find . ! -type d ! -type f ! -type l -print)"
  find . -type d -printf '%P\n' | LC_ALL=C sort > "$e/$name.dirs-$phase.txt"
  diff -u "$e/expected-directories.txt" "$e/$name.dirs-$phase.txt"
)
identity() {
  name=$1; phase=$2
  find "$CARGO_TARGET_DIR/debug" -maxdepth 2 -type f \( -name 'varve-*' -o -name 'libvarve-*' -o -name 'varve_client-*' -o -name 'libvarve_client-*' -o -name varve \) -print | LC_ALL=C sort > "$e/$name.artifact-paths-$phase.txt"
  while IFS= read -r file; do sha256sum "$file"; done < "$e/$name.artifact-paths-$phase.txt" > "$e/$name.artifacts-$phase.sha256"
  find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'varve-*.d' -o -name 'varve_client-*.d' \) -exec grep -H '^# env-dep:CARGO_MANIFEST_DIR=' {} + > "$e/$name.manifest-dir-$phase.txt" || test "$?" = 1
  mkdir "$e/$name.depinfo-$phase"
  find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'varve-*.d' -o -name 'varve_client-*.d' \) -exec cp -t "$e/$name.depinfo-$phase" {} +
}
run() {
  name=$1; shift
  gate "$name" before > "$e/$name.source-before.log" 2>&1
  identity "$name" before
  printf '%q ' "$@" > "$e/$name.command.txt"; printf '\n' >> "$e/$name.command.txt"
  set +e
  timeout 1200 "$@" 9>&- > "$e/$name.log" 2>&1
  rc=$?
  set -e
  printf '%s\n' "$rc" > "$e/$name.exit"
  gate "$name" after > "$e/$name.source-after.log" 2>&1
  identity "$name" after
  printf 'CHECK %s EXIT=%s\n' "$name" "$rc"
  tail -70 "$e/$name.log"
  return "$rc"
}
# Clean only our packages from the previous root before selecting the new one.
cd "$base/fence"
run 01-package-clean cargo clean --locked --offline -p varve-storage -p varve-client
if find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'varve-*.d' -o -name 'varve_client-*.d' \) | grep -q .; then
  echo 'Unexpected package depinfo survived targeted clean'; exit 92
fi
cd "$source_root"
set +e
# run must finish post-gates even when the test rejects its lifecycle contract.
(run 02-rollback-detach cargo test --locked --offline -p varve-storage --lib query::native::startup::transaction_rollback_detaches_catalog_callbacks_without_closing_session -- --exact --nocapture --test-threads=1)
rc=$?
set -e
printf '%s\n' "$rc" > "$e/first-gate-v1.exit"
if test -s "$e/02-rollback-detach.manifest-dir-after.txt"; then
  if grep -v -F "# env-dep:CARGO_MANIFEST_DIR=$source_root" "$e/02-rollback-detach.manifest-dir-after.txt"; then
    echo 'WRONG CARGO_MANIFEST_DIR'; exit 93
  fi
  printf 'Exact new CARGO_MANIFEST_DIR witnessed\n' > "$e/depinfo-root-verification-v1.txt"
else
  echo 'No env-dep CARGO_MANIFEST_DIR witness'; exit 94
fi
if test "$rc" -ne 0; then exit "$rc"; fi
grep -E '^test result: ok\. 1 passed; 0 failed;' "$e/02-rollback-detach.log" || exit 91

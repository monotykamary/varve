/workspace/varve-rebuild/target/debug/deps/varve_client-c533e8bf6802cb5e.d: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md

/workspace/varve-rebuild/target/debug/deps/libvarve_client-c533e8bf6802cb5e.rlib: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md

/workspace/varve-rebuild/target/debug/deps/libvarve_client-c533e8bf6802cb5e.rmeta: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md

clients/rust/src/lib.rs:
clients/rust/src/client.rs:
clients/rust/src/error.rs:
clients/rust/src/types.rs:
clients/rust/src/../README.md:

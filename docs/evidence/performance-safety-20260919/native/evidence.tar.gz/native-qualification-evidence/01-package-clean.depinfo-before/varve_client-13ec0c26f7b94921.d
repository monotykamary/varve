/workspace/varve-rebuild/target/debug/deps/varve_client-13ec0c26f7b94921.d: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libvarve_client-13ec0c26f7b94921.rmeta: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md Cargo.toml

clients/rust/src/lib.rs:
clients/rust/src/client.rs:
clients/rust/src/error.rs:
clients/rust/src/types.rs:
clients/rust/src/../README.md:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

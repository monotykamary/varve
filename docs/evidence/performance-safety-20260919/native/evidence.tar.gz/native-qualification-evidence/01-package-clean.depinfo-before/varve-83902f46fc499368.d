/workspace/varve-rebuild/target/debug/deps/varve-83902f46fc499368.d: src/main.rs src/service.rs src/pg_transport.rs src/service_retirement_tests.rs src/transport.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libvarve-83902f46fc499368.rmeta: src/main.rs src/service.rs src/pg_transport.rs src/service_retirement_tests.rs src/transport.rs Cargo.toml

src/main.rs:
src/service.rs:
src/pg_transport.rs:
src/service_retirement_tests.rs:
src/transport.rs:
Cargo.toml:

# env-dep:CARGO_PKG_VERSION=0.1.0
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

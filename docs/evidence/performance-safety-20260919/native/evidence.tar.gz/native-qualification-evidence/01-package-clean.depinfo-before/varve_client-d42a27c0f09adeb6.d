/workspace/varve-rebuild/target/debug/deps/varve_client-d42a27c0f09adeb6.d: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/client/tests.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libvarve_client-d42a27c0f09adeb6.rmeta: clients/rust/src/lib.rs clients/rust/src/client.rs clients/rust/src/client/tests.rs clients/rust/src/error.rs clients/rust/src/types.rs clients/rust/src/../README.md Cargo.toml

clients/rust/src/lib.rs:
clients/rust/src/client.rs:
clients/rust/src/client/tests.rs:
clients/rust/src/error.rs:
clients/rust/src/types.rs:
clients/rust/src/../README.md:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

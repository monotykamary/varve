/workspace/varve-rebuild/target/debug/deps/varve-d6de32a45caadb2d.d: src/main.rs src/service.rs src/pg_transport.rs src/transport.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libvarve-d6de32a45caadb2d.rmeta: src/main.rs src/service.rs src/pg_transport.rs src/transport.rs Cargo.toml

src/main.rs:
src/service.rs:
src/pg_transport.rs:
src/transport.rs:
Cargo.toml:

# env-dep:CARGO_PKG_VERSION=0.1.0
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

#!/bin/bash
set -uo pipefail
e=/workspace/varve-rebuild/performance-safety-20260919/native-qualification-evidence
check() {
  bash --noprofile --norc "$e/qualify-command-v1.sh" "$@"
  rc=$?
  printf '%s %s\n' "$1" "$rc" >> "$e/matrix-v1.results"
}
check 04-existing-native-default cargo test --locked --offline -p varve-storage --lib query::native_tests:: -- --test-threads=1
check 05-native-races-default cargo test --locked --offline -p varve-storage --lib query::native_race_tests:: -- --test-threads=1
check 06-workers-default cargo test --locked --offline -p varve-storage --lib query::workers:: -- --test-threads=1
check 07-integration-default cargo test --locked --offline -p varve-storage --test rebuilt_engine --test query --test query_boundary --test query_catalog_exposure --test query_projection --test query_residency --test query_security --test query_typed_inputs --test query_workers --test model --test residency --test raw_pressure --test resident_pruning -- --test-threads=1
check 08-native-fault cargo test --locked --offline -p varve-storage --lib --features fault-injection query::native -- --test-threads=1
check 09-clippy-default cargo clippy --locked --offline --workspace --all-targets -- -D warnings
check 10-clippy-fault cargo clippy --locked --offline --workspace --all-targets --features fault-injection -- -D warnings
check 11-fmt-check cargo fmt --all -- --check
cat "$e/matrix-v1.results"

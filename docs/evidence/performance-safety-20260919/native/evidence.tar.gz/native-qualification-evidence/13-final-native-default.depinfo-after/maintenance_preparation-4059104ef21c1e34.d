/workspace/varve-rebuild/target/debug/deps/maintenance_preparation-4059104ef21c1e34.d: tests/maintenance_preparation.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmaintenance_preparation-4059104ef21c1e34.rmeta: tests/maintenance_preparation.rs Cargo.toml

tests/maintenance_preparation.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

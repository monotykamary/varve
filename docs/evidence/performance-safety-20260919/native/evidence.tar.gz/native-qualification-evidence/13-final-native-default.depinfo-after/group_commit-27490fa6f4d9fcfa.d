/workspace/varve-rebuild/target/debug/deps/group_commit-27490fa6f4d9fcfa.d: tests/group_commit.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libgroup_commit-27490fa6f4d9fcfa.rmeta: tests/group_commit.rs Cargo.toml

tests/group_commit.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

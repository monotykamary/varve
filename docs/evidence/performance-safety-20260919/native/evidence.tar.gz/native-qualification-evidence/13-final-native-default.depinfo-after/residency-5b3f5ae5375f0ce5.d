/workspace/varve-rebuild/target/debug/deps/residency-5b3f5ae5375f0ce5.d: tests/residency.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libresidency-5b3f5ae5375f0ce5.rmeta: tests/residency.rs Cargo.toml

tests/residency.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/maintenance_work-7e667a956bf95ae1.d: tests/maintenance_work.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmaintenance_work-7e667a956bf95ae1.rmeta: tests/maintenance_work.rs Cargo.toml

tests/maintenance_work.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/derived_state-acef118010073fe1.d: tests/derived_state.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libderived_state-acef118010073fe1.rmeta: tests/derived_state.rs Cargo.toml

tests/derived_state.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

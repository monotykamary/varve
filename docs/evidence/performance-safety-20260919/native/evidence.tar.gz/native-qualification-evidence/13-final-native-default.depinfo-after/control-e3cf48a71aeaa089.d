/workspace/varve-rebuild/target/debug/deps/control-e3cf48a71aeaa089.d: tests/control.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libcontrol-e3cf48a71aeaa089.rmeta: tests/control.rs Cargo.toml

tests/control.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

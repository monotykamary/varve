/workspace/varve-rebuild/target/debug/deps/service-d50fb2a5831e6301.d: tests/service.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libservice-d50fb2a5831e6301.rmeta: tests/service.rs Cargo.toml

tests/service.rs:
Cargo.toml:

# env-dep:CARGO_BIN_EXE_varve=placeholder:varve
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/prefix_admission-80937095281394d8.d: tests/prefix_admission.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libprefix_admission-80937095281394d8.rmeta: tests/prefix_admission.rs Cargo.toml

tests/prefix_admission.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

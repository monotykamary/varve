/workspace/varve-rebuild/target/debug/deps/residency-e9867da0bd8b3dea.d: tests/residency.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libresidency-e9867da0bd8b3dea.rmeta: tests/residency.rs Cargo.toml

tests/residency.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

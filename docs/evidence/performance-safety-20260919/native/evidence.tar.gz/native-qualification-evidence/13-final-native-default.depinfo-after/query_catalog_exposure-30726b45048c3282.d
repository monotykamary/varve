/workspace/varve-rebuild/target/debug/deps/query_catalog_exposure-30726b45048c3282.d: tests/query_catalog_exposure.rs

/workspace/varve-rebuild/target/debug/deps/query_catalog_exposure-30726b45048c3282: tests/query_catalog_exposure.rs

tests/query_catalog_exposure.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification

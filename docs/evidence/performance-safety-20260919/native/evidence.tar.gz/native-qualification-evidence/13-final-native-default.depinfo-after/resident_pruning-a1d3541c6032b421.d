/workspace/varve-rebuild/target/debug/deps/resident_pruning-a1d3541c6032b421.d: tests/resident_pruning.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libresident_pruning-a1d3541c6032b421.rmeta: tests/resident_pruning.rs Cargo.toml

tests/resident_pruning.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

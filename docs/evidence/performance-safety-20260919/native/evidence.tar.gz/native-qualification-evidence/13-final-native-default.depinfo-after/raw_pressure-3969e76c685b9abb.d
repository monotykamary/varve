/workspace/varve-rebuild/target/debug/deps/raw_pressure-3969e76c685b9abb.d: tests/raw_pressure.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libraw_pressure-3969e76c685b9abb.rmeta: tests/raw_pressure.rs Cargo.toml

tests/raw_pressure.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

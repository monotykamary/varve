/workspace/varve-rebuild/target/debug/deps/admission-08b502d2f25f876b.d: tests/admission.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libadmission-08b502d2f25f876b.rmeta: tests/admission.rs Cargo.toml

tests/admission.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

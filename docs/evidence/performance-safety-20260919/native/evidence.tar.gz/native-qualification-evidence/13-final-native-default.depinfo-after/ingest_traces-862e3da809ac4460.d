/workspace/varve-rebuild/target/debug/deps/ingest_traces-862e3da809ac4460.d: tests/ingest_traces.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libingest_traces-862e3da809ac4460.rmeta: tests/ingest_traces.rs Cargo.toml

tests/ingest_traces.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

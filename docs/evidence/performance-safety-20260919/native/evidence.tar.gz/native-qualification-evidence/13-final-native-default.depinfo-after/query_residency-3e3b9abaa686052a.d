/workspace/varve-rebuild/target/debug/deps/query_residency-3e3b9abaa686052a.d: tests/query_residency.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_residency-3e3b9abaa686052a.rmeta: tests/query_residency.rs Cargo.toml

tests/query_residency.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

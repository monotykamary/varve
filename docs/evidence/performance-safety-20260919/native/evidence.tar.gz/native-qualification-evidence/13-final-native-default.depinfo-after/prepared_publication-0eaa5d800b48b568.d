/workspace/varve-rebuild/target/debug/deps/prepared_publication-0eaa5d800b48b568.d: tests/prepared_publication.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libprepared_publication-0eaa5d800b48b568.rmeta: tests/prepared_publication.rs Cargo.toml

tests/prepared_publication.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/resident_pruning-b3b71d849e793ea5.d: tests/resident_pruning.rs

/workspace/varve-rebuild/target/debug/deps/resident_pruning-b3b71d849e793ea5: tests/resident_pruning.rs

tests/resident_pruning.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification

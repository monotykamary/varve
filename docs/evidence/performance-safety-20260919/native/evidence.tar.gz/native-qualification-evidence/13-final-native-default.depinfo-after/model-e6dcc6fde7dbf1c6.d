/workspace/varve-rebuild/target/debug/deps/model-e6dcc6fde7dbf1c6.d: tests/model.rs tests/../docs/CONFIGURATION.md Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmodel-e6dcc6fde7dbf1c6.rmeta: tests/model.rs tests/../docs/CONFIGURATION.md Cargo.toml

tests/model.rs:
tests/../docs/CONFIGURATION.md:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

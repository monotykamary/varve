/workspace/varve-rebuild/target/debug/deps/derived_state-9b3964b92490f582.d: tests/derived_state.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libderived_state-9b3964b92490f582.rmeta: tests/derived_state.rs Cargo.toml

tests/derived_state.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/publication-4f26adbc888439c7.d: tests/publication.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libpublication-4f26adbc888439c7.rmeta: tests/publication.rs Cargo.toml

tests/publication.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

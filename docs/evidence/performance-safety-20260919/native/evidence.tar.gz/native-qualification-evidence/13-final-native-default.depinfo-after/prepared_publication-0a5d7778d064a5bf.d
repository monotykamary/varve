/workspace/varve-rebuild/target/debug/deps/prepared_publication-0a5d7778d064a5bf.d: tests/prepared_publication.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libprepared_publication-0a5d7778d064a5bf.rmeta: tests/prepared_publication.rs Cargo.toml

tests/prepared_publication.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

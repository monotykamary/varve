/workspace/varve-rebuild/target/debug/deps/admission-b2e8b8c334899fe5.d: tests/admission.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libadmission-b2e8b8c334899fe5.rmeta: tests/admission.rs Cargo.toml

tests/admission.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

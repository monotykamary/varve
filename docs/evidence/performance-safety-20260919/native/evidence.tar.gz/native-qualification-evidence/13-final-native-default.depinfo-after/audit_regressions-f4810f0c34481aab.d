/workspace/varve-rebuild/target/debug/deps/audit_regressions-f4810f0c34481aab.d: tests/audit_regressions.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libaudit_regressions-f4810f0c34481aab.rmeta: tests/audit_regressions.rs Cargo.toml

tests/audit_regressions.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

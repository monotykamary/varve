/workspace/varve-rebuild/target/debug/deps/query_boundary-b7beafd73102e2c0.d: tests/query_boundary.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_boundary-b7beafd73102e2c0.rmeta: tests/query_boundary.rs Cargo.toml

tests/query_boundary.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

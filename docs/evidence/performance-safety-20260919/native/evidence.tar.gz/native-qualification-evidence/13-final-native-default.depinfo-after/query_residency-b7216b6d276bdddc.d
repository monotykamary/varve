/workspace/varve-rebuild/target/debug/deps/query_residency-b7216b6d276bdddc.d: tests/query_residency.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_residency-b7216b6d276bdddc.rmeta: tests/query_residency.rs Cargo.toml

tests/query_residency.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/publication-795205c6fdd1c129.d: tests/publication.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libpublication-795205c6fdd1c129.rmeta: tests/publication.rs Cargo.toml

tests/publication.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/group_commit-7e5a4d771b4254ab.d: tests/group_commit.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libgroup_commit-7e5a4d771b4254ab.rmeta: tests/group_commit.rs Cargo.toml

tests/group_commit.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/query_workers-34c8cf9b52afe927.d: tests/query_workers.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_workers-34c8cf9b52afe927.rmeta: tests/query_workers.rs Cargo.toml

tests/query_workers.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/rebuilt_engine-4c7c9e5d7b042666.d: tests/rebuilt_engine.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/librebuilt_engine-4c7c9e5d7b042666.rmeta: tests/rebuilt_engine.rs Cargo.toml

tests/rebuilt_engine.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/residency-90306ab1ab205f69.d: tests/residency.rs

/workspace/varve-rebuild/target/debug/deps/residency-90306ab1ab205f69: tests/residency.rs

tests/residency.rs:

/workspace/varve-rebuild/target/debug/deps/scheduler-79ac6a55f3be7041.d: tests/scheduler.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libscheduler-79ac6a55f3be7041.rmeta: tests/scheduler.rs Cargo.toml

tests/scheduler.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/journal_engine-dce3f6a227ffbb50.d: tests/journal_engine.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libjournal_engine-dce3f6a227ffbb50.rmeta: tests/journal_engine.rs Cargo.toml

tests/journal_engine.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

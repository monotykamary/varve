/workspace/varve-rebuild/target/debug/deps/background_io-1defe60ecbd249e5.d: tests/background_io.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libbackground_io-1defe60ecbd249e5.rmeta: tests/background_io.rs Cargo.toml

tests/background_io.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

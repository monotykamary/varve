/workspace/varve-rebuild/target/debug/deps/prefix_checkpoint-21f81d4367c9b210.d: tests/prefix_checkpoint.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libprefix_checkpoint-21f81d4367c9b210.rmeta: tests/prefix_checkpoint.rs Cargo.toml

tests/prefix_checkpoint.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

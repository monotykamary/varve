/workspace/varve-rebuild/target/debug/deps/plan_nested-4937d9c828c83cb6.d: tests/plan_nested.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libplan_nested-4937d9c828c83cb6.rmeta: tests/plan_nested.rs Cargo.toml

tests/plan_nested.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/model-336f9fb19021246c.d: tests/model.rs tests/../docs/CONFIGURATION.md Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmodel-336f9fb19021246c.rmeta: tests/model.rs tests/../docs/CONFIGURATION.md Cargo.toml

tests/model.rs:
tests/../docs/CONFIGURATION.md:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

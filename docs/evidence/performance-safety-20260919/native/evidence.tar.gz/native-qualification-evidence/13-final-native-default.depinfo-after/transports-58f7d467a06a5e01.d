/workspace/varve-rebuild/target/debug/deps/transports-58f7d467a06a5e01.d: tests/transports.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libtransports-58f7d467a06a5e01.rmeta: tests/transports.rs Cargo.toml

tests/transports.rs:
Cargo.toml:

# env-dep:CARGO_BIN_EXE_varve=placeholder:varve
# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

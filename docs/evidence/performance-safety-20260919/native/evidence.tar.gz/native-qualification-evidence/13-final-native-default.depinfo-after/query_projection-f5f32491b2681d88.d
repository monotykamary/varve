/workspace/varve-rebuild/target/debug/deps/query_projection-f5f32491b2681d88.d: tests/query_projection.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_projection-f5f32491b2681d88.rmeta: tests/query_projection.rs Cargo.toml

tests/query_projection.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/security-ccb70a8ef09c520f.d: tests/security.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libsecurity-ccb70a8ef09c520f.rmeta: tests/security.rs Cargo.toml

tests/security.rs:
Cargo.toml:

# env-dep:CARGO_BIN_EXE_varve=placeholder:varve
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

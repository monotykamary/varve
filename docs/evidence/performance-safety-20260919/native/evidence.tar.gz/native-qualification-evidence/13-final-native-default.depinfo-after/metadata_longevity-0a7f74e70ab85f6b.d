/workspace/varve-rebuild/target/debug/deps/metadata_longevity-0a7f74e70ab85f6b.d: tests/metadata_longevity.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmetadata_longevity-0a7f74e70ab85f6b.rmeta: tests/metadata_longevity.rs Cargo.toml

tests/metadata_longevity.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

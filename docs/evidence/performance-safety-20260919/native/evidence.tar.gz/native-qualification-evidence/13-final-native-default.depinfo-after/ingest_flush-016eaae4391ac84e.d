/workspace/varve-rebuild/target/debug/deps/ingest_flush-016eaae4391ac84e.d: tests/ingest_flush.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libingest_flush-016eaae4391ac84e.rmeta: tests/ingest_flush.rs Cargo.toml

tests/ingest_flush.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

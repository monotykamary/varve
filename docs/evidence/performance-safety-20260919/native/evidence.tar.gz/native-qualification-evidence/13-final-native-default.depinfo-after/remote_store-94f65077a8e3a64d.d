/workspace/varve-rebuild/target/debug/deps/remote_store-94f65077a8e3a64d.d: tests/remote_store.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libremote_store-94f65077a8e3a64d.rmeta: tests/remote_store.rs Cargo.toml

tests/remote_store.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

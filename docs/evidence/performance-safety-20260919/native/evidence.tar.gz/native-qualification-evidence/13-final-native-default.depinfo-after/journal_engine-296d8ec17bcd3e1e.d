/workspace/varve-rebuild/target/debug/deps/journal_engine-296d8ec17bcd3e1e.d: tests/journal_engine.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libjournal_engine-296d8ec17bcd3e1e.rmeta: tests/journal_engine.rs Cargo.toml

tests/journal_engine.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

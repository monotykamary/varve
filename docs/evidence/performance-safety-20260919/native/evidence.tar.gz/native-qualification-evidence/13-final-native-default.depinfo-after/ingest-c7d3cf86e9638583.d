/workspace/varve-rebuild/target/debug/deps/ingest-c7d3cf86e9638583.d: tests/ingest.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libingest-c7d3cf86e9638583.rmeta: tests/ingest.rs Cargo.toml

tests/ingest.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/query_catalog_exposure-652c004d4bf4511a.d: tests/query_catalog_exposure.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_catalog_exposure-652c004d4bf4511a.rmeta: tests/query_catalog_exposure.rs Cargo.toml

tests/query_catalog_exposure.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

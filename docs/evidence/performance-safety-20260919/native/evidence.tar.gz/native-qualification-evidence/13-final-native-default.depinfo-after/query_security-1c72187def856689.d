/workspace/varve-rebuild/target/debug/deps/query_security-1c72187def856689.d: tests/query_security.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_security-1c72187def856689.rmeta: tests/query_security.rs Cargo.toml

tests/query_security.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/model-e4e21511e0459b2b.d: tests/model.rs tests/../docs/CONFIGURATION.md

/workspace/varve-rebuild/target/debug/deps/model-e4e21511e0459b2b: tests/model.rs tests/../docs/CONFIGURATION.md

tests/model.rs:
tests/../docs/CONFIGURATION.md:

/workspace/varve-rebuild/target/debug/deps/security-d17e50e70678f2bf.d: tests/security.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libsecurity-d17e50e70678f2bf.rmeta: tests/security.rs Cargo.toml

tests/security.rs:
Cargo.toml:

# env-dep:CARGO_BIN_EXE_varve=placeholder:varve
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

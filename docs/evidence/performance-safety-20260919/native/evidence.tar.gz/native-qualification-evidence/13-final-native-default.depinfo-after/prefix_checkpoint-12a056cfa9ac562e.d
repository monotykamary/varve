/workspace/varve-rebuild/target/debug/deps/prefix_checkpoint-12a056cfa9ac562e.d: tests/prefix_checkpoint.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libprefix_checkpoint-12a056cfa9ac562e.rmeta: tests/prefix_checkpoint.rs Cargo.toml

tests/prefix_checkpoint.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/varve-rebuild/performance-safety-20260919/native-qualification
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

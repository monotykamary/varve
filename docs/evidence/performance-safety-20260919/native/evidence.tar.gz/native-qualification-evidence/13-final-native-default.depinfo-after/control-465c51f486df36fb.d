/workspace/varve-rebuild/target/debug/deps/control-465c51f486df36fb.d: tests/control.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libcontrol-465c51f486df36fb.rmeta: tests/control.rs Cargo.toml

tests/control.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

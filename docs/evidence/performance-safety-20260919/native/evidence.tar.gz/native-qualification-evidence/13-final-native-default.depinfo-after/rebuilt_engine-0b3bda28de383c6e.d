/workspace/varve-rebuild/target/debug/deps/rebuilt_engine-0b3bda28de383c6e.d: tests/rebuilt_engine.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/librebuilt_engine-0b3bda28de383c6e.rmeta: tests/rebuilt_engine.rs Cargo.toml

tests/rebuilt_engine.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

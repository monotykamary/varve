/workspace/varve-rebuild/target/debug/deps/scheduler-b2b72120d4a285a3.d: tests/scheduler.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libscheduler-b2b72120d4a285a3.rmeta: tests/scheduler.rs Cargo.toml

tests/scheduler.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

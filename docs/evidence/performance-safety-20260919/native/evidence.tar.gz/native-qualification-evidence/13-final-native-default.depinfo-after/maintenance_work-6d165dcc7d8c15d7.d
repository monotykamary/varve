/workspace/varve-rebuild/target/debug/deps/maintenance_work-6d165dcc7d8c15d7.d: tests/maintenance_work.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmaintenance_work-6d165dcc7d8c15d7.rmeta: tests/maintenance_work.rs Cargo.toml

tests/maintenance_work.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/query-daf85479cfa72d70.d: tests/query.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery-daf85479cfa72d70.rmeta: tests/query.rs Cargo.toml

tests/query.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

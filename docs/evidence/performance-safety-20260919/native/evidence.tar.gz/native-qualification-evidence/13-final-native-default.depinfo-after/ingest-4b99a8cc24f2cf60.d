/workspace/varve-rebuild/target/debug/deps/ingest-4b99a8cc24f2cf60.d: tests/ingest.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libingest-4b99a8cc24f2cf60.rmeta: tests/ingest.rs Cargo.toml

tests/ingest.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

/workspace/varve-rebuild/target/debug/deps/journal_remote-d8148c144bcd7350.d: tests/journal_remote.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libjournal_remote-d8148c144bcd7350.rmeta: tests/journal_remote.rs Cargo.toml

tests/journal_remote.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

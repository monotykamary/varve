/workspace/varve-rebuild/target/debug/deps/query-ad6ff5b94d68e159.d: tests/query.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery-ad6ff5b94d68e159.rmeta: tests/query.rs Cargo.toml

tests/query.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

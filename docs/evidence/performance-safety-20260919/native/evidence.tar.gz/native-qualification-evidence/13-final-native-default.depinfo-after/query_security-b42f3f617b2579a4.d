/workspace/varve-rebuild/target/debug/deps/query_security-b42f3f617b2579a4.d: tests/query_security.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libquery_security-b42f3f617b2579a4.rmeta: tests/query_security.rs Cargo.toml

tests/query_security.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

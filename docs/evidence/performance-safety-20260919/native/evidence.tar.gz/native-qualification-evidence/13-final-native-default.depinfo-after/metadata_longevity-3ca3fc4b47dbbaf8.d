/workspace/varve-rebuild/target/debug/deps/metadata_longevity-3ca3fc4b47dbbaf8.d: tests/metadata_longevity.rs Cargo.toml

/workspace/varve-rebuild/target/debug/deps/libmetadata_longevity-3ca3fc4b47dbbaf8.rmeta: tests/metadata_longevity.rs Cargo.toml

tests/metadata_longevity.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

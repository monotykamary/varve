/workspace/varve-rebuild/target/debug/examples/basic-159d971844acc5d2.d: clients/rust/examples/basic.rs Cargo.toml

/workspace/varve-rebuild/target/debug/examples/libbasic-159d971844acc5d2.rmeta: clients/rust/examples/basic.rs Cargo.toml

clients/rust/examples/basic.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR

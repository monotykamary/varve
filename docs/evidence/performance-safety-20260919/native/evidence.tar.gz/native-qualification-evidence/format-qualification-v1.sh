#!/bin/bash
set -euo pipefail
base=/workspace/varve-rebuild/performance-safety-20260919
source_root="$base/native-qualification"
e="$base/native-qualification-evidence"
export PATH=/root/.cargo/bin:/workspace/varve-rebuild/baseline/.tools:$PATH
export CARGO_TARGET_DIR=/workspace/varve-rebuild/target CARGO_BUILD_JOBS=2
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_DEV_INCREMENTAL=false
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_INCREMENTAL=false
export VARVE_DUCKDB_CLI=/workspace/varve-rebuild/baseline/.tools/duckdb
export VARVE_DUCKDB_V2_LIBRARY=/workspace/varve-rebuild/baseline/.tools/duckdb-native-v2.0.0-alpha41533-linux-amd64/libduckdb.so
name=$1; shift
test ! -e "$e/$name.exit" || { echo 'Refusing to overwrite checkpoint'; exit 95; }
exec 9>/workspace/varve-rebuild/cargo-owner.lock
flock -n 9 || { echo 'Another Cargo owner is active'; exit 90; }
printf 'supervisor_pid=%s\nsource_root=%s\n' "$$" "$source_root" > "$e/${name}.owner.txt"
trap 'printf "supervisor_exit=%s\n" "$?" >> "$e/${name}.owner.txt"' EXIT
{
  rustc --version; cargo --version
  env | LC_ALL=C sort | grep -E '^(CARGO_(TARGET_DIR|BUILD_JOBS|PROFILE_)|VARVE_DUCKDB_|PATH=)'
  printf 'Exact feature flags are recorded in the command file\n'
} > "$e/${name}.environment.txt"
gate() (
  name=$1; phase=$2
  cd "$source_root"
  test "$(sha256sum "$e/source-files.sha256" | cut -c1-64)" = 6bb9ae816d7c585b459735f069817eb37609b1932e80b77b593db86361b7da7a
  test "$(sha256sum "$e/owned-files.sha256" | cut -c1-64)" = 06b572241f8caef445645648b51c174db33ed8169d3d4ffd4ef82d3b276611b6
  sha256sum -c "$e/source-files.sha256"
  sha256sum -c "$e/owned-files.sha256"
  test ! -L .tools
  test "$(find . -type l -print)" = ./.tools/duckdb
  test "$(readlink .tools/duckdb)" = "$VARVE_DUCKDB_CLI"
  test "$(sha256sum .tools/duckdb | cut -c1-64)" = 1dd0a1596505613a439dced4fb5f5800471badec82b2dc3b2c0efbd46fafbf6d
  test "$(sha256sum "$VARVE_DUCKDB_V2_LIBRARY" | cut -c1-64)" = 69bdd44e0d2426e7ba44ed14644b54d8bd99a9703e5cbb4aec3f8beef40f817d
  printf '.tools/duckdb -> %s\n' "$(readlink .tools/duckdb)"
  sha256sum .tools/duckdb "$VARVE_DUCKDB_V2_LIBRARY"
  find . -type f -printf '%P\n' | LC_ALL=C sort > "$e/$name.paths-$phase.txt"
  diff -u "$e/source-files132.txt" "$e/$name.paths-$phase.txt"
  test -z "$(find . ! -type d ! -type f ! -type l -print)"
  find . -type d -printf '%P\n' | LC_ALL=C sort > "$e/$name.dirs-$phase.txt"
  diff -u "$e/expected-directories.txt" "$e/$name.dirs-$phase.txt"
)
identity() {
  name=$1; phase=$2
  find "$CARGO_TARGET_DIR/debug" -maxdepth 2 -type f \( -name 'varve-*' -o -name 'libvarve-*' -o -name 'varve_client-*' -o -name 'libvarve_client-*' -o -name varve \) -print | LC_ALL=C sort > "$e/$name.artifact-paths-$phase.txt"
  while IFS= read -r file; do sha256sum "$file"; done < "$e/$name.artifact-paths-$phase.txt" > "$e/$name.artifacts-$phase.sha256"
  find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'varve-*.d' -o -name 'varve_client-*.d' \) -exec grep -H '^# env-dep:CARGO_MANIFEST_DIR=' {} + > "$e/$name.manifest-dir-$phase.txt" || test "$?" = 1
  mkdir "$e/$name.depinfo-$phase"
  find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f \( -name 'varve-*.d' -o -name 'varve_client-*.d' \) -exec cp -t "$e/$name.depinfo-$phase" {} +
}
run() {
  name=$1; shift
  gate "$name" before > "$e/$name.source-before.log" 2>&1
  identity "$name" before
  printf '%q ' "$@" > "$e/$name.command.txt"; printf '\n' >> "$e/$name.command.txt"
  set +e
  timeout 1200 "$@" 9>&- > "$e/$name.log" 2>&1
  rc=$?
  set -e
  printf '%s\n' "$rc" > "$e/$name.exit"
  gate "$name" after > "$e/$name.source-after.log" 2>&1
  identity "$name" after
  printf 'CHECK %s EXIT=%s\n' "$name" "$rc"
  tail -70 "$e/$name.log"
  return "$rc"
}
cd "$source_root"
name=12-remote-format
gate "$name" before > "$e/$name.source-before.log" 2>&1
identity "$name" before
tar --format=ustar -czf "$e/source132-before-format.tar.gz" -T "$e/source-files132.txt"
printf 'cargo fmt --all\n' > "$e/$name.command.txt"
set +e
cargo fmt --all 9>&- > "$e/$name.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$e/$name.exit"
test "$rc" = 0
while IFS= read -r path; do sha256sum "$path"; done < "$e/source-files132.txt" > "$e/source-files-formatted.sha256"
while IFS= read -r path; do sha256sum "$path"; done < "$e/owned-files.txt" > "$e/owned-files-formatted.sha256"
awk 'NR==FNR { original[$2]=$1; next } original[$2]!=$1 {print $2}' "$e/source-files.sha256" "$e/source-files-formatted.sha256" > "$e/formatted-changed-paths.txt"
while IFS= read -r path; do
  grep -Fxq "$path" "$e/owned-files.txt" || { echo "Unexpected changed path $path"; exit 96; }
done < "$e/formatted-changed-paths.txt"
source_hash=$(sha256sum "$e/source-files-formatted.sha256" | cut -c1-64)
owned_hash=$(sha256sum "$e/owned-files-formatted.sha256" | cut -c1-64)
# Change only the gate's frozen manifest parameters for the new formatting checkpoint.
eval "$(declare -f gate | sed -e 's/source-files.sha256/source-files-formatted.sha256/g' -e 's/owned-files.sha256/owned-files-formatted.sha256/g' -e "s/6bb9ae816d7c585b459735f069817eb37609b1932e80b77b593db86361b7da7a/$source_hash/g" -e "s/06b572241f8caef445645648b51c174db33ed8169d3d4ffd4ef82d3b276611b6/$owned_hash/g")"
gate "$name" after > "$e/$name.source-after.log" 2>&1
identity "$name" after
sha256sum "$e/source-files-formatted.sha256" "$e/owned-files-formatted.sha256"
cat "$e/formatted-changed-paths.txt"
sed -e 's/source-files.sha256/source-files-formatted.sha256/g' -e 's/owned-files.sha256/owned-files-formatted.sha256/g' -e "s/6bb9ae816d7c585b459735f069817eb37609b1932e80b77b593db86361b7da7a/$source_hash/g" -e "s/06b572241f8caef445645648b51c174db33ed8169d3d4ffd4ef82d3b276611b6/$owned_hash/g" "$e/qualify-command-v1.sh" > "$e/qualify-command-v2.sh"

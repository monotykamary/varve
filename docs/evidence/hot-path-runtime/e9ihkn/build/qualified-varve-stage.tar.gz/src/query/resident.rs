use super::*;
use std::collections::{BTreeMap, BTreeSet};
use std::sync::Weak;

#[cfg(test)]
#[path = "resident_tests.rs"]
mod tests;

#[cfg(test)]
#[path = "resident_descriptor_tests.rs"]
mod descriptor_delta_tests;

type BatchKey = (String, String);

#[derive(Clone, Copy, Debug, Default)]
struct DescriptorWork {
    #[cfg(test)]
    scope_comparisons: usize,
    #[cfg(test)]
    scope_builds: usize,
    #[cfg(test)]
    setup_builds: usize,
    #[cfg(test)]
    relation_rows_compared: usize,
    #[cfg(test)]
    relation_builds: usize,
    #[cfg(test)]
    payload_clones: usize,
}

impl DescriptorWork {
    fn scope_comparison(&mut self) {
        #[cfg(test)]
        {
            self.scope_comparisons += 1;
        }
    }
    fn scope_build(&mut self) {
        #[cfg(test)]
        {
            self.scope_builds += 1;
        }
    }
    fn setup_build(&mut self) {
        #[cfg(test)]
        {
            self.setup_builds += 1;
        }
    }
    fn relation_row_compared(&mut self) {
        #[cfg(test)]
        {
            self.relation_rows_compared += 1;
        }
    }
    fn relation_build(&mut self) {
        #[cfg(test)]
        {
            self.relation_builds += 1;
        }
    }
    fn payload_clone(&mut self) {
        #[cfg(test)]
        {
            self.payload_clones += 1;
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Budget {
    used: usize,
    limit: usize,
}

impl Budget {
    fn new(limit: usize) -> Self {
        Self { used: 0, limit }
    }

    fn debit(&mut self, additional: usize) -> Result<()> {
        let total = self
            .used
            .checked_add(additional)
            .context("resident input accounting overflow")?;
        ensure!(
            total <= self.limit,
            "DuckDB resident logical input and batch metadata exceeds {} bytes",
            self.limit
        );
        self.used = total;
        Ok(())
    }
}

struct BuildContext<'a> {
    budget: Budget,
    deadline: Instant,
    cancelled: &'a AtomicBool,
    work: DescriptorWork,
}

impl<'a> BuildContext<'a> {
    fn new(limit: usize, deadline: Instant, cancelled: &'a AtomicBool) -> Self {
        Self {
            budget: Budget::new(limit),
            deadline,
            cancelled,
            work: DescriptorWork::default(),
        }
    }

    fn check(&self) -> Result<()> {
        check_deadline(self.deadline, self.cancelled)
    }
}

fn checked_size(current: usize, additional: usize) -> Result<usize> {
    current
        .checked_add(additional)
        .context("resident input accounting overflow")
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct TableScopeDescriptor {
    name: String,
    files: Vec<PathBuf>,
    cutoff_us: Option<i64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct CatalogScopeDescriptor {
    name: String,
    columns: Vec<(String, String)>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct AliasScopeDescriptor {
    name: String,
    source: String,
    width_us: i64,
}

#[derive(Clone, Debug)]
struct QueryScopeDescriptor {
    tables: Vec<TableScopeDescriptor>,
    catalog: Vec<CatalogScopeDescriptor>,
    aliases: Vec<AliasScopeDescriptor>,
    setup: String,
    logical_bytes: usize,
}

impl QueryScopeDescriptor {
    fn matches_source(
        &self,
        tables: &[QueryTable],
        catalog: &QueryCatalog,
        deadline: Instant,
        cancelled: &AtomicBool,
    ) -> Result<bool> {
        if self.tables.len() != tables.len()
            || self.catalog.len() != catalog.relations.len()
            || self.aliases.len() != catalog.aggregates.len()
        {
            return Ok(false);
        }
        for (prepared, source) in self.tables.iter().zip(tables) {
            check_deadline(deadline, cancelled)?;
            if prepared.name != source.name
                || prepared.files != source.files
                || prepared.cutoff_us != source.cutoff_us
            {
                return Ok(false);
            }
        }
        for (prepared, source) in self.catalog.iter().zip(&catalog.relations) {
            check_deadline(deadline, cancelled)?;
            if prepared.name != source.name || prepared.columns != source.columns {
                return Ok(false);
            }
        }
        for (prepared, source) in self.aliases.iter().zip(&catalog.aggregates) {
            check_deadline(deadline, cancelled)?;
            if prepared.name != source.name
                || prepared.source != source.source
                || prepared.width_us != source.width_us
            {
                return Ok(false);
            }
        }
        Ok(true)
    }

    fn same_typed_scope(&self, other: &Self) -> bool {
        self.tables == other.tables
            && self.catalog == other.catalog
            && self.aliases == other.aliases
    }

    fn source_logical_bytes(
        tables: &[QueryTable],
        catalog: &QueryCatalog,
        context: &BuildContext<'_>,
    ) -> Result<usize> {
        context.check()?;
        let mut bytes = std::mem::size_of::<Self>();
        for table in tables {
            context.check()?;
            bytes = checked_size(bytes, std::mem::size_of::<TableScopeDescriptor>())?;
            bytes = checked_size(bytes, table.name.len())?;
            for file in &table.files {
                bytes = checked_size(bytes, std::mem::size_of::<PathBuf>())?;
                bytes = checked_size(bytes, file.as_os_str().as_encoded_bytes().len())?;
            }
        }
        for relation in &catalog.relations {
            context.check()?;
            bytes = checked_size(bytes, std::mem::size_of::<CatalogScopeDescriptor>())?;
            bytes = checked_size(bytes, relation.name.len())?;
            for (name, kind) in &relation.columns {
                bytes = checked_size(bytes, std::mem::size_of::<(String, String)>())?;
                bytes = checked_size(bytes, name.len())?;
                bytes = checked_size(bytes, kind.len())?;
            }
        }
        for alias in &catalog.aggregates {
            context.check()?;
            bytes = checked_size(bytes, std::mem::size_of::<AliasScopeDescriptor>())?;
            bytes = checked_size(bytes, alias.name.len())?;
            bytes = checked_size(bytes, alias.source.len())?;
        }
        Ok(bytes)
    }

    fn new(
        tables: &[QueryTable],
        options: &QueryOptions,
        catalog: &QueryCatalog,
        source_bytes: usize,
        context: &mut BuildContext<'_>,
    ) -> Result<Arc<Self>> {
        context.check()?;
        let empty_tables: Vec<_> = tables
            .iter()
            .map(|table| QueryTable {
                name: table.name.clone(),
                hot: vec![],
                files: table.files.clone(),
                rollups: vec![],
                cutoff_us: table.cutoff_us,
            })
            .collect();
        let empty_catalog = QueryCatalog {
            relations: catalog
                .relations
                .iter()
                .map(|relation| CatalogRelation {
                    name: relation.name.clone(),
                    columns: relation.columns.clone(),
                    rows: vec![],
                })
                .collect(),
            aggregates: catalog.aggregates.clone(),
        };
        let (setup, input) = build_query_mode(
            &empty_tables,
            "",
            options,
            &empty_catalog,
            Path::new("."),
            false,
        )?;
        debug_assert!(input.is_empty());
        let (_, setup) = setup
            .split_once("CREATE TEMP TABLE __varve_version_gate")
            .context("missing resident version gate")?;
        let setup = format!("CREATE TEMP TABLE __varve_version_gate{setup}");
        ensure!(
            setup.len() <= MAX_QUERY_SCRIPT_BYTES,
            "resident schema exceeds SQL script limit"
        );
        context.budget.debit(setup.len())?;
        let logical_bytes = checked_size(source_bytes, setup.len())?;
        let table_descriptors = tables
            .iter()
            .map(|table| TableScopeDescriptor {
                name: table.name.clone(),
                files: table.files.clone(),
                cutoff_us: table.cutoff_us,
            })
            .collect::<Vec<_>>();
        let catalog_descriptors = catalog
            .relations
            .iter()
            .map(|relation| CatalogScopeDescriptor {
                name: relation.name.clone(),
                columns: relation.columns.clone(),
            })
            .collect::<Vec<_>>();
        let alias_descriptors = catalog
            .aggregates
            .iter()
            .map(|alias| AliasScopeDescriptor {
                name: alias.name.clone(),
                source: alias.source.clone(),
                width_us: alias.width_us,
            })
            .collect::<Vec<_>>();
        context.work.scope_build();
        context.work.setup_build();
        Ok(Arc::new(Self {
            tables: table_descriptors,
            catalog: catalog_descriptors,
            aliases: alias_descriptors,
            setup,
            logical_bytes,
        }))
    }

    fn cutoff(&self, table: &str) -> Option<i64> {
        self.tables
            .iter()
            .find(|scope| scope.name == table)
            .expect("validated resident table")
            .cutoff_us
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct ExactF64(u64);

impl ExactF64 {
    fn new(value: f64, context: &str) -> Result<Self> {
        ensure!(value.is_finite(), "{context} must be finite");
        Ok(Self(value.to_bits()))
    }

    fn get(self) -> f64 {
        f64::from_bits(self.0)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedRollupRow {
    width_us: i64,
    bucket_us: i64,
    tenant: String,
    series: String,
    tags: BTreeMap<String, String>,
    count: u64,
    sum: ExactF64,
    min: ExactF64,
    max: ExactF64,
    first: ExactF64,
    last: ExactF64,
    first_timestamp_us: i64,
    last_timestamp_us: i64,
    first_sequence: u64,
    first_ordinal: u32,
    last_sequence: u64,
    last_ordinal: u32,
}

impl PreparedRollupRow {
    fn new(row: &RollupRow, work: &mut DescriptorWork) -> Result<Self> {
        let sum = ExactF64::new(row.sum, "rollup sum")?;
        let min = ExactF64::new(row.min, "rollup min")?;
        let max = ExactF64::new(row.max, "rollup max")?;
        let first = ExactF64::new(row.first, "rollup first")?;
        let last = ExactF64::new(row.last, "rollup last")?;
        work.payload_clone();
        Ok(Self {
            width_us: row.width_us,
            bucket_us: row.bucket_us,
            tenant: row.tenant.clone(),
            series: row.series.clone(),
            tags: row.tags.clone(),
            count: row.count,
            sum,
            min,
            max,
            first,
            last,
            first_timestamp_us: row.first_timestamp_us,
            last_timestamp_us: row.last_timestamp_us,
            first_sequence: row.first_sequence,
            first_ordinal: row.first_ordinal,
            last_sequence: row.last_sequence,
            last_ordinal: row.last_ordinal,
        })
    }

    fn matches(&self, row: &RollupRow) -> bool {
        self.width_us == row.width_us
            && self.bucket_us == row.bucket_us
            && self.tenant == row.tenant
            && self.series == row.series
            && self.tags == row.tags
            && self.count == row.count
            && self.sum.0 == row.sum.to_bits()
            && self.min.0 == row.min.to_bits()
            && self.max.0 == row.max.to_bits()
            && self.first.0 == row.first.to_bits()
            && self.last.0 == row.last.to_bits()
            && self.first_timestamp_us == row.first_timestamp_us
            && self.last_timestamp_us == row.last_timestamp_us
            && self.first_sequence == row.first_sequence
            && self.first_ordinal == row.first_ordinal
            && self.last_sequence == row.last_sequence
            && self.last_ordinal == row.last_ordinal
    }

    fn source_logical_bytes(row: &RollupRow) -> Result<usize> {
        ExactF64::new(row.sum, "rollup sum")?;
        ExactF64::new(row.min, "rollup min")?;
        ExactF64::new(row.max, "rollup max")?;
        ExactF64::new(row.first, "rollup first")?;
        ExactF64::new(row.last, "rollup last")?;
        let mut bytes = std::mem::size_of::<Self>();
        bytes = checked_size(bytes, row.tenant.len())?;
        bytes = checked_size(bytes, row.series.len())?;
        for (key, value) in &row.tags {
            bytes = checked_size(bytes, key.len())?;
            bytes = checked_size(bytes, value.len())?;
            bytes = checked_size(bytes, 64)?;
        }
        Ok(bytes)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedCatalogValue {
    Null,
    Text(String),
    Signed(i64),
    Unsigned(u64),
    Double(ExactF64),
    Boolean(bool),
}

impl PreparedCatalogValue {
    fn new(value: &Value, column_type: &str, work: &mut DescriptorWork) -> Result<Self> {
        if value.is_null() {
            return Ok(Self::Null);
        }
        match column_type {
            "VARCHAR" => {
                let value = value.as_str().context("catalog VARCHAR value")?;
                work.payload_clone();
                Ok(Self::Text(value.to_owned()))
            }
            "BIGINT" => Ok(Self::Signed(
                value.as_i64().context("catalog BIGINT value")?,
            )),
            "UBIGINT" => Ok(Self::Unsigned(
                value.as_u64().context("catalog UBIGINT value")?,
            )),
            "DOUBLE" => Ok(Self::Double(ExactF64::new(
                value.as_f64().context("catalog DOUBLE value")?,
                "catalog DOUBLE value",
            )?)),
            "BOOLEAN" => Ok(Self::Boolean(
                value.as_bool().context("catalog BOOLEAN value")?,
            )),
            _ => bail!("unsupported catalog column type {column_type:?}"),
        }
    }

    fn matches(&self, value: &Value, column_type: &str) -> bool {
        match (self, column_type) {
            (Self::Null, _) => value.is_null(),
            (Self::Text(prepared), "VARCHAR") => value.as_str() == Some(prepared),
            (Self::Signed(prepared), "BIGINT") => value.as_i64() == Some(*prepared),
            (Self::Unsigned(prepared), "UBIGINT") => value.as_u64() == Some(*prepared),
            (Self::Double(prepared), "DOUBLE") => value
                .as_f64()
                .is_some_and(|value| value.to_bits() == prepared.0),
            (Self::Boolean(prepared), "BOOLEAN") => value.as_bool() == Some(*prepared),
            _ => false,
        }
    }

    fn to_json(&self) -> Value {
        match self {
            Self::Null => Value::Null,
            Self::Text(value) => Value::String(value.clone()),
            Self::Signed(value) => Value::Number((*value).into()),
            Self::Unsigned(value) => Value::Number((*value).into()),
            Self::Double(value) => Value::Number(
                serde_json::Number::from_f64(value.get()).expect("validated finite float"),
            ),
            Self::Boolean(value) => Value::Bool(*value),
        }
    }

    fn source_logical_bytes(value: &Value, column_type: &str) -> Result<usize> {
        catalog_type(column_type)?;
        if value.is_null() {
            return Ok(std::mem::size_of::<Self>());
        }
        let dynamic = match column_type {
            "VARCHAR" => value.as_str().context("catalog VARCHAR value")?.len(),
            "BIGINT" => {
                value.as_i64().context("catalog BIGINT value")?;
                0
            }
            "UBIGINT" => {
                value.as_u64().context("catalog UBIGINT value")?;
                0
            }
            "DOUBLE" => {
                ExactF64::new(
                    value.as_f64().context("catalog DOUBLE value")?,
                    "catalog DOUBLE value",
                )?;
                0
            }
            "BOOLEAN" => {
                value.as_bool().context("catalog BOOLEAN value")?;
                0
            }
            _ => unreachable!("catalog_type validated the type"),
        };
        checked_size(std::mem::size_of::<Self>(), dynamic)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
enum RelationKey {
    Rollup(String),
    Catalog(String),
}

impl RelationKey {
    fn name(&self) -> &str {
        match self {
            Self::Rollup(name) | Self::Catalog(name) => name,
        }
    }

    fn is_rollup(&self, name: &str) -> bool {
        matches!(self, Self::Rollup(current) if current == name)
    }

    fn is_catalog(&self, name: &str) -> bool {
        matches!(self, Self::Catalog(current) if current == name)
    }

    fn append_delete(&self, script: &mut String) {
        let kind = match self {
            Self::Rollup(_) => "rollup",
            Self::Catalog(_) => "catalog",
        };
        script.push_str("DELETE FROM __varve_input WHERE kind = ");
        script.push_str(&quote_literal(kind));
        script.push_str(" AND table_name = ");
        script.push_str(&quote_literal(self.name()));
        script.push_str(";\n");
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedRelationRows {
    Rollup(Vec<PreparedRollupRow>),
    Catalog(Vec<Vec<PreparedCatalogValue>>),
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct RelationDescriptor {
    key: RelationKey,
    rows: PreparedRelationRows,
    logical_bytes: usize,
}

const RELATION_MAP_ENTRY_BYTES: usize =
    std::mem::size_of::<Arc<RelationDescriptor>>() + 4 * std::mem::size_of::<usize>();

fn relation_map_key_bytes(name: &str) -> Result<usize> {
    checked_size(std::mem::size_of::<RelationKey>(), name.len())
}

impl RelationDescriptor {
    fn rollup_source_logical_bytes(
        table: &QueryTable,
        context: &BuildContext<'_>,
    ) -> Result<usize> {
        let mut bytes = checked_size(std::mem::size_of::<Self>(), table.name.len())?;
        for row in &table.rollups {
            context.check()?;
            bytes = checked_size(bytes, PreparedRollupRow::source_logical_bytes(row)?)?;
        }
        Ok(bytes)
    }

    fn catalog_source_logical_bytes(
        relation: &CatalogRelation,
        context: &BuildContext<'_>,
    ) -> Result<usize> {
        let outer_rows = relation
            .rows
            .len()
            .checked_mul(std::mem::size_of::<Vec<PreparedCatalogValue>>())
            .context("resident input accounting overflow")?;
        let mut bytes = checked_size(std::mem::size_of::<Self>(), relation.name.len())?;
        bytes = checked_size(bytes, outer_rows)?;
        for row in &relation.rows {
            context.check()?;
            match row {
                Value::Array(values) => {
                    ensure!(
                        values.len() == relation.columns.len(),
                        "catalog relation {} row has {} values for {} columns",
                        relation.name,
                        values.len(),
                        relation.columns.len()
                    );
                    for (value, (_, column_type)) in values.iter().zip(&relation.columns) {
                        bytes = checked_size(
                            bytes,
                            PreparedCatalogValue::source_logical_bytes(value, column_type)?,
                        )?;
                    }
                }
                Value::Object(values) => {
                    ensure!(
                        values.len() == relation.columns.len(),
                        "catalog relation {} row has {} fields for {} columns",
                        relation.name,
                        values.len(),
                        relation.columns.len()
                    );
                    for (name, column_type) in &relation.columns {
                        let value = values.get(name).with_context(|| {
                            format!("catalog relation {} row is missing {name}", relation.name)
                        })?;
                        bytes = checked_size(
                            bytes,
                            PreparedCatalogValue::source_logical_bytes(value, column_type)?,
                        )?;
                    }
                }
                _ => bail!(
                    "catalog relation {} row must be an array or object",
                    relation.name
                ),
            }
        }
        Ok(bytes)
    }

    fn from_rollups(
        table: &QueryTable,
        logical_bytes: usize,
        context: &mut BuildContext<'_>,
    ) -> Result<Arc<Self>> {
        let mut rows = Vec::with_capacity(table.rollups.len());
        for row in &table.rollups {
            context.check()?;
            rows.push(PreparedRollupRow::new(row, &mut context.work)?);
        }
        context.work.relation_build();
        Ok(Arc::new(Self {
            key: RelationKey::Rollup(table.name.clone()),
            rows: PreparedRelationRows::Rollup(rows),
            logical_bytes,
        }))
    }

    fn from_catalog(
        relation: &CatalogRelation,
        logical_bytes: usize,
        context: &mut BuildContext<'_>,
    ) -> Result<Arc<Self>> {
        let mut rows = Vec::with_capacity(relation.rows.len());
        for row in &relation.rows {
            context.check()?;
            let values = catalog_row_values(relation, row)?;
            let mut prepared = Vec::with_capacity(values.len());
            for (value, (_, column_type)) in values.into_iter().zip(&relation.columns) {
                prepared.push(PreparedCatalogValue::new(
                    value,
                    column_type,
                    &mut context.work,
                )?);
            }
            rows.push(prepared);
        }
        context.work.relation_build();
        Ok(Arc::new(Self {
            key: RelationKey::Catalog(relation.name.clone()),
            rows: PreparedRelationRows::Catalog(rows),
            logical_bytes,
        }))
    }

    fn matches_rollups(
        &self,
        table: &QueryTable,
        deadline: Instant,
        cancelled: &AtomicBool,
        work: &mut DescriptorWork,
    ) -> Result<bool> {
        let PreparedRelationRows::Rollup(prepared) = &self.rows else {
            return Ok(false);
        };
        if !self.key.is_rollup(&table.name) || prepared.len() != table.rollups.len() {
            return Ok(false);
        }
        for (prepared, source) in prepared.iter().zip(&table.rollups) {
            check_deadline(deadline, cancelled)?;
            work.relation_row_compared();
            if !prepared.matches(source) {
                return Ok(false);
            }
        }
        Ok(true)
    }

    fn matches_catalog(
        &self,
        relation: &CatalogRelation,
        deadline: Instant,
        cancelled: &AtomicBool,
        work: &mut DescriptorWork,
    ) -> Result<bool> {
        let PreparedRelationRows::Catalog(prepared) = &self.rows else {
            return Ok(false);
        };
        if !self.key.is_catalog(&relation.name) || prepared.len() != relation.rows.len() {
            return Ok(false);
        }
        for (prepared, source) in prepared.iter().zip(&relation.rows) {
            check_deadline(deadline, cancelled)?;
            work.relation_row_compared();
            let source = catalog_row_values(relation, source)?;
            if prepared.len() != source.len()
                || !prepared.iter().zip(source).zip(&relation.columns).all(
                    |((prepared, source), (_, column_type))| prepared.matches(source, column_type),
                )
            {
                return Ok(false);
            }
        }
        Ok(true)
    }

    fn is_empty(&self) -> bool {
        match &self.rows {
            PreparedRelationRows::Rollup(rows) => rows.is_empty(),
            PreparedRelationRows::Catalog(rows) => rows.is_empty(),
        }
    }
}

enum RelationPlan<'a> {
    Rollup {
        table: &'a QueryTable,
        existing: Option<Arc<RelationDescriptor>>,
        logical_bytes: usize,
    },
    Catalog {
        relation: &'a CatalogRelation,
        existing: Option<Arc<RelationDescriptor>>,
        logical_bytes: usize,
    },
}

pub(super) struct ResidentRequest<'a> {
    snapshot: &'a ResidentSnapshot,
    scope: Arc<QueryScopeDescriptor>,
    relations: BTreeMap<RelationKey, Arc<RelationDescriptor>>,
    batches: BTreeMap<BatchKey, &'a ResidentBatch>,
    retained_bytes: usize,
    #[cfg(test)]
    work: DescriptorWork,
}

impl<'a> ResidentRequest<'a> {
    pub(super) fn new(
        tables: &'a [QueryTable],
        snapshot: &'a ResidentSnapshot,
        options: &QueryOptions,
        catalog: &'a QueryCatalog,
        candidates: &[&ResidentState],
        deadline: Instant,
        cancelled: &AtomicBool,
    ) -> Result<Self> {
        let mut context = BuildContext::new(MAX_QUERY_INPUT_BYTES, deadline, cancelled);
        Self::new_with_context(tables, snapshot, options, catalog, candidates, &mut context)
    }

    fn new_with_context(
        tables: &'a [QueryTable],
        snapshot: &'a ResidentSnapshot,
        options: &QueryOptions,
        catalog: &'a QueryCatalog,
        candidates: &[&ResidentState],
        context: &mut BuildContext<'_>,
    ) -> Result<Self> {
        ensure!(
            tables.iter().all(|table| table.hot.is_empty()),
            "resident query requires empty QueryTable.hot"
        );
        ensure!(
            tables.len() == snapshot.tables.len(),
            "resident table scope mismatch"
        );
        context.check()?;

        let mut matching_scope = None;
        for candidate in candidates {
            context.work.scope_comparison();
            if candidate.scope.matches_source(
                tables,
                catalog,
                context.deadline,
                context.cancelled,
            )? {
                matching_scope = Some(Arc::clone(&candidate.scope));
                break;
            }
        }
        let scope_source_bytes = if let Some(scope) = &matching_scope {
            context.budget.debit(scope.logical_bytes)?;
            None
        } else {
            let bytes = QueryScopeDescriptor::source_logical_bytes(tables, catalog, context)?;
            context.budget.debit(bytes)?;
            Some(bytes)
        };

        context.budget.debit(snapshot.namespace.len())?;
        // Borrowed indexes keep scope/identity validation O(n log n), not a
        // prefix scan for every batch. Scope storage was already admitted above.
        let selected: BTreeSet<_> = tables.iter().map(|table| table.name.as_str()).collect();
        ensure!(
            selected.len() == tables.len(),
            "resident table scope mismatch"
        );
        let mut names = BTreeSet::new();
        for table in &snapshot.tables {
            context.check()?;
            let table_bytes = checked_size(table.name.len(), 256)?;
            context.budget.debit(table_bytes)?;
            ensure!(
                selected.contains(table.name.as_str()) && names.insert(table.name.as_str()),
                "resident table scope mismatch"
            );
            let mut ids = BTreeSet::new();
            for batch in &table.batches {
                context.check()?;
                let mut batch_bytes = checked_size(batch.id.len(), table.name.len())?;
                batch_bytes = checked_size(batch_bytes, 256)?;
                context.budget.debit(batch_bytes)?;
                ensure!(
                    ids.insert(batch.id.as_str()),
                    "duplicate resident batch identity"
                );
            }
        }

        let mut plans = Vec::new();
        for table in tables {
            context.check()?;
            context.budget.debit(RELATION_MAP_ENTRY_BYTES)?;
            context.budget.debit(relation_map_key_bytes(&table.name)?)?;
            let key = RelationKey::Rollup(table.name.clone());
            let mut existing = None;
            for candidate in candidates {
                if let Some(descriptor) = candidate.relations.get(&key)
                    && descriptor.matches_rollups(
                        table,
                        context.deadline,
                        context.cancelled,
                        &mut context.work,
                    )?
                {
                    existing = Some(Arc::clone(descriptor));
                    break;
                }
            }
            let logical_bytes = match &existing {
                Some(descriptor) => descriptor.logical_bytes,
                None => RelationDescriptor::rollup_source_logical_bytes(table, context)?,
            };
            context.budget.debit(logical_bytes)?;
            plans.push((
                key,
                RelationPlan::Rollup {
                    table,
                    existing,
                    logical_bytes,
                },
            ));
        }
        for relation in &catalog.relations {
            context.check()?;
            context.budget.debit(RELATION_MAP_ENTRY_BYTES)?;
            context
                .budget
                .debit(relation_map_key_bytes(&relation.name)?)?;
            let key = RelationKey::Catalog(relation.name.clone());
            let mut existing = None;
            for candidate in candidates {
                if let Some(descriptor) = candidate.relations.get(&key)
                    && descriptor.matches_catalog(
                        relation,
                        context.deadline,
                        context.cancelled,
                        &mut context.work,
                    )?
                {
                    existing = Some(Arc::clone(descriptor));
                    break;
                }
            }
            let logical_bytes = match &existing {
                Some(descriptor) => descriptor.logical_bytes,
                None => RelationDescriptor::catalog_source_logical_bytes(relation, context)?,
            };
            context.budget.debit(logical_bytes)?;
            plans.push((
                key,
                RelationPlan::Catalog {
                    relation,
                    existing,
                    logical_bytes,
                },
            ));
        }

        let scope = match matching_scope {
            Some(scope) => scope,
            None => QueryScopeDescriptor::new(
                tables,
                options,
                catalog,
                scope_source_bytes.expect("new scope has a source charge"),
                context,
            )?,
        };
        let retained_bytes = context.budget.used;

        let mut relations = BTreeMap::new();
        for (key, plan) in plans {
            let descriptor = match plan {
                RelationPlan::Rollup {
                    table,
                    existing,
                    logical_bytes,
                } => match existing {
                    Some(descriptor) => descriptor,
                    None => RelationDescriptor::from_rollups(table, logical_bytes, context)?,
                },
                RelationPlan::Catalog {
                    relation,
                    existing,
                    logical_bytes,
                } => match existing {
                    Some(descriptor) => descriptor,
                    None => RelationDescriptor::from_catalog(relation, logical_bytes, context)?,
                },
            };
            ensure!(
                relations.insert(key, descriptor).is_none(),
                "duplicate resident relation"
            );
        }

        let mut batches = BTreeMap::new();
        for table in &snapshot.tables {
            for batch in &table.batches {
                ensure!(
                    batches
                        .insert((table.name.clone(), batch.id.clone()), batch)
                        .is_none(),
                    "duplicate resident batch identity"
                );
            }
        }
        Ok(Self {
            snapshot,
            scope,
            relations,
            batches,
            retained_bytes,
            #[cfg(test)]
            work: context.work,
        })
    }
}

struct LoadedBatch {
    rows_identity: Weak<Vec<StoredRow>>,
    rows: usize,
    bytes: usize,
    charged_bytes: usize,
}

pub(super) struct ResidentState {
    namespace: String,
    sequence: u64,
    scope: Arc<QueryScopeDescriptor>,
    batches: BTreeMap<BatchKey, LoadedBatch>,
    relations: BTreeMap<RelationKey, Arc<RelationDescriptor>>,
    pub(super) rows: usize,
    pub(super) bytes: usize,
}

impl ResidentState {
    pub(super) fn compatible(&self, request: &ResidentRequest<'_>) -> bool {
        self.namespace == request.snapshot.namespace
            && self.sequence <= request.snapshot.sequence
            && self.scope.same_typed_scope(&request.scope)
            && self.batches.iter().all(|(key, loaded)| {
                request.batches.get(key).is_some_and(|batch| {
                    loaded.rows_identity.ptr_eq(&Arc::downgrade(&batch.rows))
                        && loaded.charged_bytes == batch.charged_bytes
                })
            })
    }

    pub(super) fn batch_count(&self) -> usize {
        self.batches.len()
    }
}

struct ResidentInstallPlan<'a> {
    full: bool,
    missing_batches: Vec<(&'a BatchKey, &'a ResidentBatch)>,
    changed_relations: Vec<&'a Arc<RelationDescriptor>>,
}

impl<'a> ResidentInstallPlan<'a> {
    fn new(state: Option<&ResidentState>, request: &'a ResidentRequest<'a>) -> Result<Self> {
        if let Some(state) = state {
            ensure!(state.compatible(request), "incompatible resident worker");
        }
        let full = state.is_none();
        let missing_batches = request
            .batches
            .iter()
            .filter(|(key, _)| state.is_none_or(|state| !state.batches.contains_key(*key)))
            .map(|(key, batch)| (key, *batch))
            .collect();
        let changed_relations = request
            .relations
            .iter()
            .filter_map(|(key, descriptor)| {
                state
                    .and_then(|state| state.relations.get(key))
                    .is_none_or(|installed| installed.as_ref() != descriptor.as_ref())
                    .then_some(descriptor)
            })
            .collect();
        if let Some(state) = state {
            let current: BTreeSet<_> = request.relations.keys().collect();
            ensure!(
                state.relations.keys().all(|key| current.contains(key)),
                "resident relation removal requires rebuild"
            );
        }
        Ok(Self {
            full,
            missing_batches,
            changed_relations,
        })
    }
}

fn charge(current: usize, additional: usize) -> Result<usize> {
    let total = current
        .checked_add(additional)
        .context("resident input accounting overflow")?;
    ensure!(
        total <= MAX_QUERY_INPUT_BYTES,
        "DuckDB resident logical input and batch metadata exceeds 128 MiB"
    );
    Ok(total)
}

fn append_relation_input(input: &mut Vec<u8>, relation: &RelationDescriptor) -> Result<()> {
    match &relation.rows {
        PreparedRelationRows::Rollup(rows) => {
            let RelationKey::Rollup(table_name) = &relation.key else {
                bail!("rollup descriptor key mismatch");
            };
            for row in rows {
                append_json_line(
                    input,
                    &RollupInput {
                        kind: "rollup",
                        table_name,
                        width_us: row.width_us,
                        bucket_us: row.bucket_us,
                        tenant: &row.tenant,
                        series: &row.series,
                        tags: serde_json::to_string(&row.tags)?,
                        count: row.count,
                        sum: row.sum.get(),
                        min: row.min.get(),
                        max: row.max.get(),
                        first: row.first.get(),
                        last: row.last.get(),
                        first_timestamp_us: row.first_timestamp_us,
                        last_timestamp_us: row.last_timestamp_us,
                        first_sequence: row.first_sequence,
                        first_ordinal: row.first_ordinal,
                        last_sequence: row.last_sequence,
                        last_ordinal: row.last_ordinal,
                    },
                )?;
            }
        }
        PreparedRelationRows::Catalog(rows) => {
            let RelationKey::Catalog(relation_name) = &relation.key else {
                bail!("catalog descriptor key mismatch");
            };
            for row in rows {
                let values = row
                    .iter()
                    .map(PreparedCatalogValue::to_json)
                    .collect::<Vec<_>>();
                append_json_line(
                    input,
                    &json!({
                        "kind": "catalog",
                        "table_name": relation_name,
                        "tags": serde_json::to_string(&values)?,
                    }),
                )?;
            }
        }
    }
    Ok(())
}

impl Worker {
    pub(super) fn install_resident(
        &mut self,
        request: ResidentRequest<'_>,
        options: &QueryOptions,
        deadline: Instant,
        cancelled: &AtomicBool,
    ) -> Result<QueryWorkerStats> {
        self.resident_attempted = true;
        let plan = ResidentInstallPlan::new(self.resident.as_ref(), &request)?;
        let mut state = self.resident.take().unwrap_or_else(|| ResidentState {
            namespace: request.snapshot.namespace.clone(),
            sequence: request.snapshot.sequence,
            scope: Arc::clone(&request.scope),
            batches: BTreeMap::new(),
            relations: BTreeMap::new(),
            rows: 0,
            bytes: 0,
        });
        let mut bytes = request.retained_bytes;
        let mut rows = 0_usize;
        let mut input = Vec::new();
        let mut additions = 0;
        let mut staged_rows = 0_u64;
        for (key, batch) in &plan.missing_batches {
            check_deadline(deadline, cancelled)?;
            charge(bytes, batch.charged_bytes)?;
            let cutoff = request.scope.cutoff(&key.0);
            let start = input.len();
            let mut logical = 0_usize;
            let mut count = 0;
            for row in batch.rows.iter() {
                check_deadline(deadline, cancelled)?;
                if cutoff.is_some_and(|cutoff| row.row.timestamp_us < cutoff) {
                    continue;
                }
                row.row.validate().context("validate resident query row")?;
                logical = charge(logical, row.row.estimated_bytes().saturating_add(16))?;
                append_json_line(
                    &mut input,
                    &HotInput {
                        kind: "hot",
                        table_name: &key.0,
                        timestamp_us: row.row.timestamp_us,
                        tenant: &row.row.tenant,
                        series: &row.row.series,
                        value: row.row.value,
                        tags: serde_json::to_string(&row.row.tags)?,
                        sequence: row.sequence,
                        ordinal: row.ordinal,
                    },
                )?;
                count += 1;
            }
            let batch_bytes = logical.max(input.len() - start).max(batch.charged_bytes);
            state.batches.insert(
                (*key).clone(),
                LoadedBatch {
                    rows_identity: Arc::downgrade(&batch.rows),
                    rows: count,
                    bytes: batch_bytes,
                    charged_bytes: batch.charged_bytes,
                },
            );
            additions += 1;
            staged_rows = staged_rows.saturating_add(count as u64);
        }
        let raw_staged_bytes = input.len() as u64;
        let dynamic_start = input.len();
        for relation in &plan.changed_relations {
            check_deadline(deadline, cancelled)?;
            append_relation_input(&mut input, relation)?;
        }
        let dynamic_staged_bytes = u64::try_from(input.len() - dynamic_start).unwrap_or(u64::MAX);
        charge(0, input.len())?;
        for (key, batch) in &request.batches {
            let loaded = &state.batches[key];
            bytes = charge(bytes, loaded.bytes)?;
            rows = rows
                .checked_add(loaded.rows)
                .context("resident row count overflow")?;
            ensure!(
                loaded.rows_identity.ptr_eq(&Arc::downgrade(&batch.rows)),
                "resident batch remapped during install"
            );
        }

        let mut script = self.configuration(options)?;
        script.push_str("BEGIN TRANSACTION;\n");
        if plan.full {
            script.push_str(&request.scope.setup);
        } else {
            for relation in &plan.changed_relations {
                relation.key.append_delete(&mut script);
            }
        }
        if !input.is_empty() {
            let mut file = tempfile::Builder::new()
                .prefix("resident-")
                .suffix(".json")
                .tempfile_in(&self.inputs)
                .context("create resident input")?;
            file.write_all(&input).context("stage resident input")?;
            file.flush().context("flush resident input")?;
            script.push_str(&format!("INSERT INTO __varve_input SELECT * FROM read_json({}, format = 'newline_delimited', auto_detect = false, columns = {{", quote_path(file.path())?));
            for (index, (name, kind)) in INPUT_COLUMNS.iter().enumerate() {
                if index > 0 {
                    script.push(',');
                }
                script.push_str(&format!(
                    "{}: {}",
                    quote_identifier(name),
                    quote_literal(kind)
                ));
            }
            script.push_str("});\n");
            script.push_str("COMMIT;\n");
            ensure!(
                script.len() <= MAX_QUERY_SCRIPT_BYTES,
                "resident SQL script exceeds limit"
            );
            ensure!(
                self.run(script, deadline, cancelled, 0)?.is_empty(),
                "unexpected resident setup output"
            );
            file.close().context("remove resident input")?;
        } else {
            script.push_str("COMMIT;\n");
            ensure!(
                script.len() <= MAX_QUERY_SCRIPT_BYTES,
                "resident SQL script exceeds limit"
            );
            if plan.full || additions != 0 || !plan.changed_relations.is_empty() {
                ensure!(
                    self.run(script, deadline, cancelled, 0)?.is_empty(),
                    "unexpected resident setup output"
                );
            }
        }
        check_deadline(deadline, cancelled)?;
        state.namespace = request.snapshot.namespace.clone();
        state.sequence = request.snapshot.sequence;
        state.scope = Arc::clone(&request.scope);
        state.relations = request.relations.clone();
        state.rows = rows;
        state.bytes = bytes;
        self.resident = Some(state);
        let dynamic_changed = plan
            .changed_relations
            .iter()
            .any(|relation| !plan.full || !relation.is_empty());
        Ok(QueryWorkerStats {
            resident_full_loads: u64::from(plan.full),
            resident_delta_loads: u64::from(!plan.full && additions != 0),
            resident_hits: u64::from(!plan.full && additions == 0),
            resident_raw_staged_rows: staged_rows,
            resident_raw_staged_bytes: raw_staged_bytes,
            resident_dynamic_loads: u64::from(dynamic_changed),
            resident_dynamic_staged_bytes: dynamic_staged_bytes,
            ..QueryWorkerStats::default()
        })
    }

    pub(super) fn configuration(&self, options: &QueryOptions) -> Result<String> {
        let mut script = String::new();
        if !self.initialized {
            let paths = self
                .key
                .files
                .iter()
                .map(|file| quote_path(file))
                .collect::<Result<Vec<_>>>()?;
            script.push_str(&format!("SET memory_limit = '{}MB'; SET threads = {}; SET max_temp_directory_size = '0B'; SET preserve_insertion_order = false; ", options.memory_mb, options.threads));
            script.push_str("SET autoinstall_known_extensions = false; SET autoload_known_extensions = false; SET allow_community_extensions = false; SET allow_unsigned_extensions = false; ");
            script.push_str(&format!("SET allowed_directories = [{}]; SET allowed_paths = [{}]; SET home_directory = {}; SET temp_directory = {}; SET enable_external_access = false; SET lock_configuration = true;\n", quote_path(&self.inputs)?, paths.join(","), quote_path(self.directory.path())?, quote_path(self.directory.path())?));
        }
        Ok(script)
    }
}

//! Source-only acceptance ledger: tests below are intentionally not run locally.
//! Main must register `pub mod journal;` and run these in its isolated sandbox.
//! Fixtures stay below a few KiB and live under the test working directory, not
//! /tmp. No clocks, sleeps, global failpoints, external services or large fixtures.

use super::*;
use std::process::Command;
use tempfile::TempDir;

fn fixture() -> TempDir {
    tempfile::Builder::new()
        .prefix(".journal-test-")
        .tempdir_in(std::env::current_dir().unwrap())
        .unwrap()
}

fn config() -> JournalConfig {
    JournalConfig {
        max_total_bytes: 4096,
        segment_bytes: 512,
        max_segments: 8,
        max_frame_bytes: 384,
        max_record_bytes: 200,
        max_records_per_group: 8,
    }
}

fn roomy() -> JournalConfig {
    JournalConfig {
        max_total_bytes: 32_768,
        segment_bytes: 4096,
        ..config()
    }
}

fn snapshot(path: &Path) -> Vec<(String, Vec<u8>)> {
    let mut files: Vec<_> = fs::read_dir(path)
        .unwrap()
        .map(|entry| {
            let entry = entry.unwrap();
            (
                entry.file_name().to_str().unwrap().to_owned(),
                fs::read(entry.path()).unwrap(),
            )
        })
        .collect();
    files.sort_by(|a, b| a.0.cmp(&b.0));
    files
}

fn replay(journal: &Journal) -> Vec<Vec<(u64, Vec<u8>)>> {
    // Only this tiny test oracle collects history. The production API does not.
    let mut groups = Vec::new();
    journal
        .scan(|group| {
            let rows: Vec<_> = group
                .records()
                .map(|(seq, data)| (seq, data.to_vec()))
                .collect();
            assert_eq!(rows.first().unwrap().0, group.first_sequence());
            assert_eq!(rows.last().unwrap().0, group.last_sequence());
            groups.push(rows);
            Ok(())
        })
        .unwrap();
    groups
}

#[test]
fn group_receipts_survive_reopen_and_keep_empty_records() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    assert!(replay(&journal).is_empty());
    let a = journal.append_group(&[b"a", b"", b"bc"]).unwrap();
    let b = journal.append_group(&[b"def"]).unwrap();
    assert_eq!((a.first_sequence(), a.last_sequence()), (1, 3));
    assert_eq!((b.first_sequence(), b.last_sequence()), (4, 4));
    let expected = vec![
        vec![(1, b"a".to_vec()), (2, vec![]), (3, b"bc".to_vec())],
        vec![(4, b"def".to_vec())],
    ];
    assert_eq!(replay(&journal), expected);
    drop(journal);
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    assert_eq!(journal.stats().recovered_records, 4);
    assert_eq!(journal.stats().durable_sequence, 4);
    assert_eq!(replay(&journal), expected);
    assert_eq!(
        journal.append_group(&[b"next"]).unwrap().first_sequence(),
        5
    );
}

#[test]
fn ordinary_groups_have_one_file_sync_and_zero_namespace_barriers() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    let opening = journal.stats();
    journal.append_group(&[b"first"]).unwrap();
    let created = journal.stats();
    assert_eq!(created.file_syncs - opening.file_syncs, 2); // header + group
    assert_eq!(created.namespace_barriers - opening.namespace_barriers, 1);
    let names: Vec<_> = snapshot(dir.path())
        .into_iter()
        .map(|(name, _)| name)
        .collect();
    for _ in 0..10 {
        journal.append_group(&[b"row", b"row2"]).unwrap();
    }
    let after = journal.stats();
    assert_eq!(after.file_syncs - created.file_syncs, 10);
    assert_eq!(after.namespace_barriers, created.namespace_barriers);
    assert_eq!(after.groups_appended - created.groups_appended, 10);
    assert_eq!(after.records_appended - created.records_appended, 20);
    assert_eq!(after.segments, 1);
    assert_eq!(
        snapshot(dir.path())
            .into_iter()
            .map(|(name, _)| name)
            .collect::<Vec<_>>(),
        names
    );
}

#[test]
fn rotation_seals_without_rewriting_and_respects_barriers() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), config()).unwrap();
    journal.append_group(&[&[1; 200]]).unwrap();
    let first_path = dir.path().join(segment_name(1));
    let unsealed = fs::read(&first_path).unwrap();
    let before = journal.stats();
    journal.append_group(&[&[2; 200]]).unwrap();
    let after = journal.stats();
    assert_eq!(after.file_syncs - before.file_syncs, 3); // seal + header + group
    assert_eq!(after.namespace_barriers - before.namespace_barriers, 1);
    assert_eq!(after.segments, 2);
    let sealed = fs::read(&first_path).unwrap();
    assert_eq!(&sealed[..unsealed.len()], unsealed.as_slice());
    assert_eq!(&sealed[unsealed.len()..unsealed.len() + 8], SEAL_MAGIC);
    journal.append_group(&[&[3; 200]]).unwrap();
    assert_eq!(fs::read(&first_path).unwrap(), sealed);
    assert_eq!(journal.stats().disk_bytes, 464 + 464 + 400);
    drop(journal);
    let journal = Journal::open(dir.path(), config()).unwrap();
    assert_eq!(
        replay(&journal),
        vec![
            vec![(1, vec![1; 200])],
            vec![(2, vec![2; 200])],
            vec![(3, vec![3; 200])]
        ]
    );
    assert_eq!(fs::read(first_path).unwrap(), sealed);
}

#[test]
fn invalid_config_precedes_directory_creation() {
    let dir = fixture();
    let mut cases = Vec::new();
    let mut c = config();
    c.max_segments = 0;
    cases.push(c);
    let mut c = config();
    c.max_segments = 65_537;
    cases.push(c);
    let mut c = config();
    c.max_records_per_group = 0;
    cases.push(c);
    let mut c = config();
    c.max_records_per_group = 65_537;
    cases.push(c);
    let mut c = config();
    c.max_record_bytes = 0;
    cases.push(c);
    let mut c = config();
    c.max_record_bytes = 249;
    cases.push(c);
    let mut c = config();
    c.max_frame_bytes = usize::MAX;
    cases.push(c);
    let mut c = config();
    c.max_frame_bytes = 136;
    cases.push(c);
    let mut c = config();
    c.segment_bytes = 511;
    cases.push(c);
    let mut c = config();
    c.segment_bytes = u64::MAX;
    cases.push(c);
    let mut c = config();
    c.max_total_bytes = 511;
    cases.push(c);
    let mut c = config();
    c.max_total_bytes = u64::MAX;
    cases.push(c);
    for (index, c) in cases.into_iter().enumerate() {
        let root = dir.path().join(format!("invalid-{index}"));
        assert!(Journal::open(&root, c).is_err());
        assert!(!root.exists());
    }
}

#[test]
fn oversize_and_capacity_rejections_leave_bytes_counters_and_sequence_unchanged() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), config()).unwrap();
    let disk = snapshot(dir.path());
    let stats = journal.stats();
    let empty: &[u8] = b"";
    for records in [
        vec![],
        vec![&[0; 201][..]],
        vec![&[0; 100][..]; 3],
        vec![empty; 9],
    ] {
        assert!(journal.append_group(&records).is_err());
        assert_eq!(journal.stats(), stats);
        assert_eq!(snapshot(dir.path()), disk);
    }
    assert_eq!(journal.append_group(&[b"ok"]).unwrap().first_sequence(), 1);
    drop(journal);

    for (max_segments, max_total_bytes) in [(8, 512), (1, 512)] {
        let dir = fixture();
        let c = JournalConfig {
            max_segments,
            max_total_bytes,
            ..config()
        };
        let mut journal = Journal::open(dir.path(), c).unwrap();
        journal.append_group(&[&[1; 200]]).unwrap();
        let before = snapshot(dir.path());
        let stats = journal.stats();
        assert!(journal.append_group(&[&[2; 200]]).is_err());
        assert_eq!(snapshot(dir.path()), before); // not even a seal was written
        assert_eq!(journal.stats(), stats);
        assert!(!journal.stats().fenced);
    }
}

#[test]
fn complete_corruption_at_every_byte_fails_closed_without_tail_repair() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    journal.append_group(&[b"alpha", b"beta"]).unwrap();
    drop(journal);
    let path = dir.path().join(segment_name(1));
    let original = fs::read(&path).unwrap();
    for offset in 0..original.len() {
        let mut corrupt = original.clone();
        corrupt[offset] ^= 0x80;
        fs::write(&path, &corrupt).unwrap();
        assert!(
            Journal::open(dir.path(), roomy()).is_err(),
            "accepted byte {offset}"
        );
        assert_eq!(fs::read(&path).unwrap(), corrupt);
    }
}

#[test]
fn every_partial_last_group_recovers_all_or_none_and_reuses_no_committed_sequence() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    journal.append_group(&[b"durable"]).unwrap();
    let prefix = fs::read(dir.path().join(segment_name(1))).unwrap();
    journal.append_group(&[b"one", b"two"]).unwrap();
    let complete = fs::read(dir.path().join(segment_name(1))).unwrap();
    let frame = &complete[prefix.len()..];
    drop(journal);
    // Physical truncation simulates an incomplete tail, not proof that arbitrary
    // hardware truncation after receipt can be distinguished from a crash append.
    for cut in 0..=frame.len() {
        let path = dir.path().join(segment_name(1));
        fs::write(&path, &complete[..prefix.len() + cut]).unwrap();
        let mut journal = Journal::open(dir.path(), roomy()).unwrap();
        let expected = if cut == frame.len() { 3 } else { 1 };
        assert_eq!(journal.stats().durable_sequence, expected, "cut {cut}");
        assert_eq!(replay(&journal).len(), if expected == 3 { 2 } else { 1 });
        assert_eq!(
            journal.stats().tail_bytes_discarded,
            if expected == 3 { 0 } else { cut as u64 }
        );
        assert_eq!(
            fs::metadata(&path).unwrap().len(),
            if expected == 3 {
                complete.len()
            } else {
                prefix.len()
            } as u64
        );
        assert_eq!(
            journal.append_group(&[b"retry"]).unwrap().first_sequence(),
            expected + 1
        );
        drop(journal);
    }
}

#[test]
fn partial_new_segment_header_is_repaired_only_at_physical_end() {
    let dir = fixture();
    let path = dir.path().join(segment_name(1));
    let header = segment_header(1, 1);
    for cut in 0..HEADER {
        fs::write(&path, &header[..cut]).unwrap();
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        assert_eq!(fs::read(&path).unwrap(), header);
        assert_eq!(journal.stats().durable_sequence, 0);
        assert_eq!(journal.append_group(&[b"ok"]).unwrap().first_sequence(), 1);
        drop(journal);
    }
    fs::write(&path, b"wrong").unwrap();
    assert!(Journal::open(dir.path(), config()).is_err());
    fs::write(&path, &header[..7]).unwrap();
    fs::write(dir.path().join(segment_name(2)), segment_header(2, 1)).unwrap();
    assert!(Journal::open(dir.path(), config()).is_err());
    assert_eq!(fs::metadata(path).unwrap().len(), 7);
}

#[test]
fn sequence_gaps_duplicates_and_missing_segment_fail_closed() {
    for bad_first in [1, 3] {
        let dir = fixture();
        let mut journal = Journal::open(dir.path(), roomy()).unwrap();
        journal.append_group(&[b"first"]).unwrap();
        drop(journal);
        let path = dir.path().join(segment_name(1));
        let frame = encode(&[b"wrong sequence"], 128 + 8 + 14, bad_first, bad_first).unwrap();
        OpenOptions::new()
            .append(true)
            .open(&path)
            .unwrap()
            .write_all(&frame)
            .unwrap();
        let before = fs::read(&path).unwrap();
        assert!(Journal::open(dir.path(), roomy()).is_err());
        assert_eq!(fs::read(&path).unwrap(), before);
    }
    for missing in [1, 2] {
        let dir = fixture();
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        for _ in 0..3 {
            journal.append_group(&[&[1; 200]]).unwrap();
        }
        drop(journal);
        fs::remove_file(dir.path().join(segment_name(missing))).unwrap();
        assert!(Journal::open(dir.path(), config()).is_err());
    }
}

#[test]
fn incomplete_or_clean_unsealed_interior_and_corrupt_seals_are_rejected() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), config()).unwrap();
    journal.append_group(&[&[1; 200]]).unwrap();
    journal.append_group(&[&[2; 200]]).unwrap();
    drop(journal);
    let path = dir.path().join(segment_name(1));
    let original = fs::read(&path).unwrap();
    for len in [7, 80, 399, 400, 401, 463] {
        fs::write(&path, &original[..len]).unwrap();
        assert!(
            Journal::open(dir.path(), config()).is_err(),
            "accepted interior length {len}"
        );
        assert_eq!(fs::metadata(&path).unwrap().len(), len as u64);
    }
    for offset in 400..original.len() {
        let mut corrupt = original.clone();
        corrupt[offset] ^= 1;
        fs::write(&path, &corrupt).unwrap();
        assert!(
            Journal::open(dir.path(), config()).is_err(),
            "accepted seal byte {offset}"
        );
    }
    // Bytes following a complete seal must not be treated as a discardable tail.
    let mut extra = original.clone();
    extra.push(0);
    fs::write(&path, extra).unwrap();
    fs::remove_file(dir.path().join(segment_name(2))).unwrap();
    assert!(Journal::open(dir.path(), config()).is_err());
}

#[test]
fn checksum_valid_untrusted_bounds_are_rejected_before_payload_read() {
    let dir = fixture();
    let path = dir.path().join(segment_name(1));
    for (size, count) in [(u64::MAX, 1), (385, 1), (136, u64::MAX), (136, 0), (128, 1)] {
        let mut header = [0u8; HEADER];
        header[..8].copy_from_slice(GROUP_MAGIC);
        put(&mut header, 8, size);
        put(&mut header, 16, 1);
        put(&mut header, 24, count);
        let digest = blake3::hash(&header[..32]);
        header[32..].copy_from_slice(digest.as_bytes());
        let mut bytes = segment_header(1, 1).to_vec();
        bytes.extend_from_slice(&header);
        fs::write(&path, &bytes).unwrap();
        assert!(Journal::open(dir.path(), config()).is_err());
        assert_eq!(fs::read(&path).unwrap(), bytes);
    }
}

#[test]
fn checksum_valid_record_extent_and_count_mismatches_fail_closed() {
    let dir = fixture();
    let path = dir.path().join(segment_name(1));
    for bad_len in [0, 4, 201, u64::MAX] {
        let mut frame = encode(&[b"abc"], 139, 1, 1).unwrap();
        put(&mut frame, HEADER, bad_len);
        let end = frame.len() - 32;
        let digest = blake3::hash(&frame[..end]);
        frame[end..].copy_from_slice(digest.as_bytes());
        let mut bytes = segment_header(1, 1).to_vec();
        bytes.extend_from_slice(&frame);
        fs::write(&path, &bytes).unwrap();
        assert!(Journal::open(dir.path(), config()).is_err());
    }
}

#[test]
fn partial_write_fences_until_reopen_and_sync_ambiguity_can_recover_whole_group() {
    for fault in [FailAt::Write, FailAt::Sync] {
        let dir = fixture();
        let mut journal = Journal::open(dir.path(), roomy()).unwrap();
        journal.append_group(&[b"durable"]).unwrap();
        journal.fault.next = Some(fault);
        assert!(journal.append_group(&[b"a", b"b"]).is_err());
        assert!(journal.stats().fenced);
        assert_eq!(journal.stats().durable_sequence, 1);
        let disk = snapshot(dir.path());
        let stats = journal.stats();
        assert!(journal.append_group(&[b"forbidden"]).is_err());
        assert!(journal.scan(|_| Ok(())).is_err());
        assert_eq!(snapshot(dir.path()), disk);
        assert_eq!(journal.stats(), stats);
        drop(journal);
        let mut journal = Journal::open(dir.path(), roomy()).unwrap();
        let recovered = if fault == FailAt::Sync { 3 } else { 1 };
        assert_eq!(journal.stats().durable_sequence, recovered);
        assert_eq!(replay(&journal).len(), if recovered == 3 { 2 } else { 1 });
        assert_eq!(
            journal.append_group(&[b"after"]).unwrap().first_sequence(),
            recovered + 1
        );
    }
}

#[test]
fn rotation_write_sync_and_namespace_failures_fence_and_recover_prefix() {
    for fault in [FailAt::Write, FailAt::Sync, FailAt::Namespace] {
        let dir = fixture();
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        journal.append_group(&[&[1; 200]]).unwrap();
        journal.fault.next = Some(fault);
        assert!(journal.append_group(&[&[2; 200]]).is_err());
        assert!(journal.stats().fenced);
        let before = snapshot(dir.path());
        assert!(journal.append_group(&[b"forbidden"]).is_err());
        assert_eq!(snapshot(dir.path()), before);
        drop(journal);
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        assert_eq!(replay(&journal), vec![vec![(1, vec![1; 200])]]);
        assert_eq!(
            journal.append_group(&[&[2; 200]]).unwrap().first_sequence(),
            2
        );
        drop(journal);
        assert_eq!(
            Journal::open(dir.path(), config())
                .unwrap()
                .stats()
                .recovered_records,
            2
        );
    }
}

#[test]
fn failed_segment_creation_fences_even_without_a_group_write() {
    for fault in [FailAt::Write, FailAt::Sync, FailAt::Namespace] {
        let dir = fixture();
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        journal.fault.next = Some(fault);
        assert!(journal.append_group(&[b"first"]).is_err());
        assert!(journal.stats().fenced);
        drop(journal);
        let mut journal = Journal::open(dir.path(), config()).unwrap();
        assert!(replay(&journal).is_empty());
        assert_eq!(
            journal.append_group(&[b"first"]).unwrap().first_sequence(),
            1
        );
    }
}

#[test]
fn directory_lock_excludes_handles_and_child_processes() {
    let dir = fixture();
    let journal = Journal::open(dir.path(), config()).unwrap();
    assert!(Journal::open(dir.path(), config()).is_err());
    run_ownership_child(dir.path(), true);
    drop(journal);
    run_ownership_child(dir.path(), false);
}

fn run_ownership_child(path: &Path, locked: bool) {
    let output = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "journal::tests::ownership_child", "--nocapture"])
        .env("VARVE_JOURNAL_CHILD_PATH", path)
        .env("VARVE_JOURNAL_CHILD_LOCKED", if locked { "1" } else { "0" })
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains("JOURNAL_OWNERSHIP_CHECKED"),
        "child test was not registered: {}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn ownership_child() {
    let Some(path) = std::env::var_os("VARVE_JOURNAL_CHILD_PATH") else {
        return;
    };
    let locked = std::env::var("VARVE_JOURNAL_CHILD_LOCKED").unwrap() == "1";
    let result = Journal::open(PathBuf::from(path), config());
    if locked {
        let error = result.err().expect("child acquired parent's directory");
        assert!(error.to_string().contains("already owned"), "{error:#}");
    } else {
        assert!(result.is_ok());
    }
    println!("JOURNAL_OWNERSHIP_CHECKED");
}

#[test]
fn scan_stops_at_callback_error_without_mutating_or_fencing() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), roomy()).unwrap();
    for _ in 0..3 {
        journal.append_group(&[b"row"]).unwrap();
    }
    let mut seen = 0;
    let stats = journal.stats();
    assert!(
        journal
            .scan(|_| {
                seen += 1;
                anyhow::bail!("consumer failed")
            })
            .is_err()
    );
    assert_eq!(seen, 1);
    assert_eq!(journal.stats(), stats);
    assert_eq!(replay(&journal).len(), 3);
}

#[test]
fn new_directory_creation_and_exact_frame_admission_are_durable() {
    let parent = fixture();
    let path = parent.path().join("journal");
    let mut journal = Journal::open(&path, config()).unwrap();
    assert_eq!(journal.stats().namespace_barriers, 2); // LOCK/root and parent
    assert_eq!(journal.stats().file_syncs, 1); // LOCK
    // 128 fixed bytes + two length words + 240 payload bytes = 384 exactly.
    let receipt = journal.append_group(&[&[1; 120], &[2; 120]]).unwrap();
    assert_eq!(receipt.last_sequence(), 2);
    assert_eq!(journal.stats().disk_bytes + SEAL, 512);
    drop(journal);
    let journal = Journal::open(&path, config()).unwrap();
    assert_eq!(
        replay(&journal),
        vec![vec![(1, vec![1; 120]), (2, vec![2; 120])]]
    );
}

#[test]
fn metadata_admission_rejects_oversized_files_total_bytes_and_segment_counts() {
    let dir = fixture();
    let path = dir.path().join(segment_name(1));
    fs::write(&path, [0; 513]).unwrap();
    let error = Journal::open(dir.path(), config()).err().unwrap();
    assert!(error.to_string().contains("segment byte admission"));
    assert_eq!(fs::metadata(&path).unwrap().len(), 513);
    fs::remove_file(path).unwrap();
    for id in 1..=9 {
        fs::write(dir.path().join(segment_name(id)), segment_header(id, 1)).unwrap();
    }
    let error = Journal::open(dir.path(), config()).err().unwrap();
    assert!(error.to_string().contains("segment count admission"));

    let dir = fixture();
    let mut journal = Journal::open(dir.path(), config()).unwrap();
    for _ in 0..2 {
        journal.append_group(&[&[1; 200]]).unwrap();
    }
    drop(journal);
    let before = snapshot(dir.path());
    let error = Journal::open(
        dir.path(),
        JournalConfig {
            max_total_bytes: 512,
            ..config()
        },
    )
    .err()
    .unwrap();
    assert!(error.to_string().contains("disk admission"));
    assert_eq!(snapshot(dir.path()), before);
}

#[test]
fn unknown_version_and_flags_fail_even_with_valid_header_checksums() {
    let dir = fixture();
    let path = dir.path().join(segment_name(1));
    for (offset, value) in [(8, 2u32), (12, 1u32)] {
        let mut header = segment_header(1, 1);
        header[offset..offset + 4].copy_from_slice(&value.to_le_bytes());
        let digest = blake3::hash(&header[..32]);
        header[32..].copy_from_slice(digest.as_bytes());
        fs::write(&path, header).unwrap();
        assert!(Journal::open(dir.path(), config()).is_err());
        assert_eq!(fs::read(&path).unwrap(), header);
    }
}

#[test]
fn foreign_files_and_tighter_reopen_bounds_are_rejected_without_deleting_history() {
    let dir = fixture();
    let mut journal = Journal::open(dir.path(), config()).unwrap();
    journal.append_group(&[&[1; 200]]).unwrap();
    drop(journal);
    let before = snapshot(dir.path());
    let smaller = JournalConfig {
        max_record_bytes: 199,
        ..config()
    };
    assert!(Journal::open(dir.path(), smaller).is_err());
    assert_eq!(snapshot(dir.path()), before);
    fs::write(dir.path().join("legacy.wal"), b"keep me").unwrap();
    assert!(Journal::open(dir.path(), config()).is_err());
    assert_eq!(fs::read(dir.path().join("legacy.wal")).unwrap(), b"keep me");
}

use super::WriteRequest;
use crate::model::{Config, Row, validate_request_id};
use crate::wal::AppendItem;
use anyhow::{Context, Result, ensure};
use std::io::{BufWriter, Write};
use std::ops::Deref;

/// Ownership is the proof: callers cannot mutate rows after admission.
pub(crate) struct AdmittedWrite {
    request: WriteRequest,
    bytes: usize,
}

impl AdmittedWrite {
    pub(crate) fn new(request: WriteRequest) -> Result<Self> {
        let bytes = request.admission_bytes()?;
        Ok(Self { request, bytes })
    }

    pub(crate) fn rows(&self) -> usize {
        self.request.rows.len()
    }

    pub(crate) fn bytes(&self) -> usize {
        self.bytes
    }

    pub(super) fn prepare(self, config: &Config) -> Result<PreparedWrite> {
        ensure!(
            self.rows() <= config.max_batch_rows,
            "batch row admission limit"
        );
        let (encoded_bytes, digest) = row_identity(&self.request.rows, config.max_batch_bytes)?;
        let resident_bytes = resident_bytes(&self.request.rows)?;
        Ok(PreparedWrite {
            item: AppendItem {
                table: self.request.table,
                request_id: self.request.request_id,
                digest,
                rows: self.request.rows,
                now_us: Some(self.request.now_us),
            },
            admission_bytes: self.bytes,
            encoded_bytes,
            resident_bytes,
        })
    }
}

pub(super) struct PreparedWrite {
    item: AppendItem,
    admission_bytes: usize,
    encoded_bytes: usize,
    resident_bytes: usize,
}

impl PreparedWrite {
    #[cfg(all(test, feature = "fault-injection"))]
    pub(super) fn with_test_admission_hint(mut self, bytes: usize) -> Self {
        self.admission_bytes = bytes;
        self
    }

    pub(super) fn admission_bytes(&self) -> usize {
        self.admission_bytes
    }

    pub(super) fn validated(&self) -> ValidatedAppend<'_> {
        ValidatedAppend {
            item: &self.item,
            encoded_bytes: self.encoded_bytes,
            resident_bytes: self.resident_bytes,
        }
    }
}

impl Deref for PreparedWrite {
    type Target = AppendItem;
    fn deref(&self) -> &Self::Target {
        &self.item
    }
}

/// A borrowed proof never outlives the immutable owner. Recovery has its own
/// validating constructor; no unchecked/trusted boolean crosses this boundary.
pub(super) struct ValidatedAppend<'a> {
    item: &'a AppendItem,
    encoded_bytes: usize,
    resident_bytes: usize,
}

impl<'a> ValidatedAppend<'a> {
    pub(super) fn recovered(item: &'a AppendItem, config: &Config) -> Result<Self> {
        validate_request_id(&item.request_id)?;
        ensure!(
            !item.rows.is_empty() && item.rows.len() <= config.max_batch_rows,
            "invalid/recovery oversized WAL batch"
        );
        let (encoded_bytes, digest) = row_identity(&item.rows, config.max_batch_bytes)?;
        ensure!(digest == item.digest, "WAL batch digest mismatch");
        for row in &item.rows {
            row.validate()?;
        }
        Ok(Self {
            item,
            encoded_bytes,
            resident_bytes: resident_bytes(&item.rows)?,
        })
    }

    pub(super) fn item(&self) -> &'a AppendItem {
        self.item
    }
    pub(super) fn resident_bytes(&self) -> usize {
        self.resident_bytes
    }
    pub(super) fn check_limits(&self, config: &Config, ordinal: usize) -> Result<()> {
        ensure!(
            !self.item.rows.is_empty()
                && self.item.rows.len() <= config.max_batch_rows
                && ordinal.saturating_add(self.item.rows.len()) <= u32::MAX as usize,
            "invalid/recovery oversized WAL batch"
        );
        ensure!(
            self.encoded_bytes <= config.max_batch_bytes,
            "batch byte admission limit"
        );
        Ok(())
    }
}

fn resident_bytes(rows: &[Row]) -> Result<usize> {
    rows.iter().try_fold(0usize, |bytes, row| {
        bytes
            .checked_add(row.estimated_bytes())
            .context("row memory accounting overflow")
    })
}

struct DigestWriter {
    hasher: blake3::Hasher,
    bytes: usize,
    limit: usize,
}

impl Write for DigestWriter {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if bytes.len() > self.limit.saturating_sub(self.bytes) {
            return Err(std::io::Error::other("batch byte admission limit"));
        }
        #[cfg(test)]
        ROW_HASH_CHUNKS.with(|count| count.set(count.get() + 1));
        self.hasher.update(bytes);
        self.bytes += bytes.len();
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

#[cfg(test)]
thread_local! {
    pub(super) static ROW_IDENTITY_PASSES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    pub(super) static ADMISSION_PASSES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    static ROW_HASH_CHUNKS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

fn row_identity(rows: &[Row], limit: usize) -> Result<(usize, String)> {
    #[cfg(test)]
    ROW_IDENTITY_PASSES.with(|count| count.set(count.get() + 1));
    // Serde emits many tiny tokens. Coalesce them in bounded scratch space
    // instead of replacing a whole-buffer hash with one hash update per token.
    let mut writer = BufWriter::with_capacity(
        limit.min(8192),
        DigestWriter {
            hasher: blake3::Hasher::new(),
            bytes: 0,
            limit,
        },
    );
    serde_json::to_writer(&mut writer, rows)?;
    writer.flush()?;
    let writer = writer.into_inner().map_err(|error| error.into_error())?;
    Ok((writer.bytes, writer.hasher.finalize().to_hex().to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;

    fn request(value: f64) -> WriteRequest {
        WriteRequest {
            table: "metrics".into(),
            request_id: "id".into(),
            now_us: 20,
            rows: vec![Row {
                timestamp_us: -1,
                tenant: "東京".into(),
                series: "quote\"\\".into(),
                value,
                tags: BTreeMap::from([("line".into(), "a\nb\t".into())]),
            }],
        }
    }

    #[test]
    fn streaming_identity_matches_canonical_bytes_and_exact_bounds() -> Result<()> {
        for value in [-0.0, 0.0, f64::MIN_POSITIVE, f64::MAX, 0.30000000000000004] {
            let request = request(value);
            let expected = serde_json::to_vec(&request.rows)?;
            let (length, digest) = row_identity(&request.rows, expected.len())?;
            assert_eq!(length, expected.len());
            assert_eq!(digest, blake3::hash(&expected).to_hex().as_str());
            assert!(row_identity(&request.rows, expected.len() - 1).is_err());
        }
        Ok(())
    }

    #[test]
    fn admission_moves_owned_rows_and_preparation_runs_identity_once() -> Result<()> {
        let request = request(-0.0);
        let rows_pointer = request.rows.as_ptr();
        let string_pointer = request.rows[0].tenant.as_ptr();
        let admission_before = ADMISSION_PASSES.with(std::cell::Cell::get);
        let admitted = AdmittedWrite::new(request)?;
        let charge = admitted.bytes();
        let before = ROW_IDENTITY_PASSES.with(std::cell::Cell::get);
        let prepared = admitted.prepare(&Config::default())?;
        assert_eq!(prepared.rows.as_ptr(), rows_pointer);
        assert_eq!(prepared.rows[0].tenant.as_ptr(), string_pointer);
        assert_eq!(prepared.admission_bytes(), charge);
        for _ in 0..3 {
            prepared.validated().check_limits(&Config::default(), 0)?;
        }
        assert_eq!(ROW_IDENTITY_PASSES.with(std::cell::Cell::get) - before, 1);
        assert_eq!(
            ADMISSION_PASSES.with(std::cell::Cell::get) - admission_before,
            1
        );
        assert_eq!(prepared.rows[0].value.to_bits(), (-0.0f64).to_bits());
        Ok(())
    }

    #[test]
    fn streaming_hash_coalesces_tokens_in_bounded_scratch() -> Result<()> {
        let row = request(0.30000000000000004).rows.pop().unwrap();
        let rows = vec![row; 512];
        let expected = serde_json::to_vec(&rows)?;
        let before = ROW_HASH_CHUNKS.with(std::cell::Cell::get);
        let (bytes, digest) = row_identity(&rows, expected.len())?;
        let updates = ROW_HASH_CHUNKS.with(std::cell::Cell::get) - before;
        assert_eq!(bytes, expected.len());
        assert_eq!(digest, blake3::hash(&expected).to_hex().as_str());
        assert!(updates > 1 && updates <= expected.len() / 4096 + 2);
        assert!(
            updates < rows.len(),
            "hash work must not amplify to per-row or per-token calls"
        );
        Ok(())
    }

    #[test]
    fn untrusted_recovery_revalidates_digest_and_static_rows() -> Result<()> {
        let prepared = AdmittedWrite::new(request(1.0))?.prepare(&Config::default())?;
        ValidatedAppend::recovered(&prepared, &Config::default())?;
        let mut forged = prepared.item.clone();
        forged.rows[0].value = 9.0;
        assert!(ValidatedAppend::recovered(&forged, &Config::default()).is_err());
        forged.digest = row_identity(&forged.rows, usize::MAX)?.1;
        ValidatedAppend::recovered(&forged, &Config::default())?;
        forged.rows[0].tenant.clear();
        forged.digest = row_identity(&forged.rows, usize::MAX)?.1;
        assert!(ValidatedAppend::recovered(&forged, &Config::default()).is_err());
        assert!(AdmittedWrite::new(request(f64::NAN)).is_err());
        assert!(AdmittedWrite::new(request(f64::INFINITY)).is_err());
        Ok(())
    }
}

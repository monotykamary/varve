//! Bounded multi-producer ingestion. Admission is not a durability acknowledgement.
#[path = "ingest_trace.rs"]
mod trace;
use trace::TraceBuffer;
pub use trace::{IngestTrace, IngestTraceSnapshot};

use crate::engine::AdmittedWrite;
use crate::{Database, WriteReceipt, WriteRequest};
use anyhow::{Context, Result, anyhow, ensure};
use crossbeam_channel::{Receiver, Sender, TrySendError, bounded};
use serde::{Deserialize, Serialize};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};
use tokio::sync::{Notify, oneshot};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct IngestConfig {
    pub queue_capacity: usize,
    pub max_pending_bytes: usize,
    pub max_group_requests: usize,
    pub max_group_rows: usize,
    pub max_group_bytes: usize,
    pub max_delay: Duration,
    /// Retain bounded same-thread group diagnostics; zero disables capture.
    pub trace_capacity: usize,
}
impl Default for IngestConfig {
    fn default() -> Self {
        Self {
            queue_capacity: 1024,
            max_pending_bytes: 16 * 1024 * 1024,
            max_group_requests: 128,
            max_group_rows: 10_000,
            max_group_bytes: 4 * 1024 * 1024,
            max_delay: Duration::from_millis(2),
            trace_capacity: 0,
        }
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct IngestStats {
    pub submitted: u64,
    pub rejected: u64,
    pub completed: u64,
    pub succeeded: u64,
    pub failed: u64,
    pub dropped_receivers: u64,
    /// Requests which encountered bounded admission pressure and waited.
    pub admission_waits: u64,
    pub waiting_requests: usize,
    pub peak_waiting_requests: usize,
    pub admission_wait_ns: u64,
    /// Waiting futures cancelled or rejected before ownership reached the queue.
    pub waits_without_admission: u64,
    /// Worker flushes, not necessarily physical frames (all-retry groups write none).
    pub groups: u64,
    pub pending_requests: usize,
    pub pending_bytes: usize,
    pub peak_pending_requests: usize,
    pub peak_pending_bytes: usize,
    pub closed: bool,
}

fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(|poison| poison.into_inner())
}

struct Pending {
    request: Option<AdmittedWrite>,
    completion: Option<oneshot::Sender<Result<WriteReceipt>>>,
    bytes: usize,
    admitted: Instant,
    stats: Arc<Mutex<IngestStats>>,
    capacity: Arc<Notify>,
}
impl Pending {
    fn finish(&mut self, result: Result<WriteReceipt>) {
        let Some(completion) = self.completion.take() else {
            return;
        };
        let succeeded = result.is_ok();
        // Release the budget before waking the producer, so a completed producer
        // can immediately submit again even with a one-request byte budget.
        let mut stats = lock(&self.stats);
        stats.pending_requests -= 1;
        stats.pending_bytes -= self.bytes;
        stats.completed = stats.completed.saturating_add(1);
        if succeeded {
            stats.succeeded = stats.succeeded.saturating_add(1);
        } else {
            stats.failed = stats.failed.saturating_add(1);
        }
        if completion.send(result).is_err() {
            stats.dropped_receivers = stats.dropped_receivers.saturating_add(1);
        }
        drop(stats);
        self.capacity.notify_waiters();
    }
}
impl Drop for Pending {
    fn drop(&mut self) {
        self.finish(Err(anyhow!(
            "ingestion worker stopped before completion; retry the same request ID"
        )));
    }
}

/// A FIFO ingestion drain result. Counts include successes and failures since startup.
/// `sequence` covers preceding successful requests; failed requests are not committed.
#[derive(Clone, Debug, Serialize)]
pub struct IngestFlush {
    pub sequence: u64,
    pub completed: u64,
    pub succeeded: u64,
    pub failed: u64,
}

enum Command {
    Write(Pending),
    Flush(oneshot::Sender<Result<IngestFlush>>),
}

struct Owner {
    admission: Mutex<Option<Sender<Command>>>,
    worker: Mutex<Option<JoinHandle<()>>>,
    config: IngestConfig,
    stats: Arc<Mutex<IngestStats>>,
    traces: Arc<Mutex<TraceBuffer>>,
    capacity: Arc<Notify>,
}
impl Owner {
    fn shutdown(&self) -> Result<()> {
        lock(&self.admission).take();
        lock(&self.stats).closed = true;
        self.capacity.notify_waiters();
        // Keep this lock through join: concurrent shutdown callers also await drain.
        if let Some(worker) = lock(&self.worker).take() {
            worker
                .join()
                .map_err(|_| anyhow!("ingestion worker panicked"))?;
        }
        Ok(())
    }
}
impl Drop for Owner {
    fn drop(&mut self) {
        let _ = self.shutdown();
    }
}

enum Admission {
    Accepted(oneshot::Receiver<Result<WriteReceipt>>),
    Full(&'static str),
}

struct AdmissionWait {
    stats: Arc<Mutex<IngestStats>>,
    started: Instant,
    admitted: bool,
}
impl AdmissionWait {
    fn new(stats: Arc<Mutex<IngestStats>>) -> Self {
        {
            let mut current = lock(&stats);
            current.admission_waits = current.admission_waits.saturating_add(1);
            current.waiting_requests += 1;
            current.peak_waiting_requests =
                current.peak_waiting_requests.max(current.waiting_requests);
        }
        Self {
            stats,
            started: Instant::now(),
            admitted: false,
        }
    }
}
impl Drop for AdmissionWait {
    fn drop(&mut self) {
        let mut stats = lock(&self.stats);
        stats.waiting_requests -= 1;
        stats.admission_wait_ns = stats
            .admission_wait_ns
            .saturating_add(u64::try_from(self.started.elapsed().as_nanos()).unwrap_or(u64::MAX));
        if !self.admitted {
            stats.waits_without_admission = stats.waits_without_admission.saturating_add(1);
        }
    }
}

#[derive(Clone)]
pub struct Ingestor {
    inner: Arc<Owner>,
}
impl Ingestor {
    pub fn new(db: Database, mut config: IngestConfig) -> Result<Self> {
        ensure!(
            config.queue_capacity > 0 && config.queue_capacity <= 1_000_000,
            "ingestion queue_capacity must be 1..1000000"
        );
        ensure!(
            config.max_pending_bytes > 0
                && config.max_group_bytes > 128
                && config.max_group_rows > 0
                && config.max_group_requests > 0
                && config.max_group_requests <= crate::wal::MAX_GROUP_REQUESTS
                && config.max_delay <= Duration::from_secs(60),
            "invalid ingestion limits"
        );
        ensure!(
            config.trace_capacity <= 1024
                && config
                    .trace_capacity
                    .saturating_mul(config.max_group_requests)
                    <= 65_536,
            "ingestion trace capacity exceeds bounded history limits"
        );
        // Engine limits still apply; clamping keeps each flush in one frame's envelope.
        config.max_group_rows = config
            .max_group_rows
            .min(db.inner.config.max_batch_rows)
            .min(db.inner.config.hot_max_rows);
        config.max_group_bytes = config
            .max_group_bytes
            .min(db.inner.config.max_batch_bytes)
            .min(db.inner.config.hot_max_bytes)
            .min(db.inner.config.wal_max_bytes as usize)
            .min(crate::wal::MAX_FRAME_BYTES);
        ensure!(
            config.max_group_bytes > 128,
            "engine byte budget is too small for ingestion"
        );
        let (sender, receiver) = bounded(config.queue_capacity);
        let stats = Arc::new(Mutex::new(IngestStats::default()));
        let worker_config = config.clone();
        let worker_stats = stats.clone();
        let traces = Arc::new(Mutex::new(TraceBuffer::new(config.trace_capacity)));
        let worker_traces = traces.clone();
        let capacity = Arc::new(Notify::new());
        let worker_capacity = capacity.clone();
        let worker = thread::Builder::new()
            .name("varve-ingest".into())
            .spawn(move || {
                consume(
                    db,
                    receiver,
                    worker_config,
                    worker_stats,
                    worker_traces,
                    worker_capacity,
                )
            })
            .context("start ingestion worker")?;
        Ok(Self {
            inner: Arc::new(Owner {
                admission: Mutex::new(Some(sender)),
                worker: Mutex::new(Some(worker)),
                config,
                stats,
                traces,
                capacity,
            }),
        })
    }

    /// A returned receiver means admitted, not committed. Err guarantees not enqueued.
    /// This nonblocking API retains its explicit full-queue rejection semantics.
    pub fn submit(&self, request: WriteRequest) -> Result<oneshot::Receiver<Result<WriteReceipt>>> {
        let result = (|| {
            let mut request = Some(AdmittedWrite::new(request)?);
            match self.try_enqueue(&mut request)? {
                Admission::Accepted(receiver) => Ok(receiver),
                Admission::Full(message) => Err(anyhow!(message)),
            }
        })();
        self.record_rejection(&result);
        result
    }

    /// Wait for queue/byte credit without discarding or revalidating the input.
    /// The caller's future retains its request until admission, outside pending
    /// queue bytes; callers must bound their concurrent futures. Transports use
    /// their existing request slots and deadlines. Cancelling while waiting does
    /// not enqueue the request. After receiving the receipt channel, cancellation
    /// does not cancel publication: retry only with the same request identity.
    pub async fn submit_wait(
        &self,
        request: WriteRequest,
    ) -> Result<oneshot::Receiver<Result<WriteReceipt>>> {
        let result = async {
            let mut request = Some(AdmittedWrite::new(request)?);
            let mut waiting: Option<AdmissionWait> = None;
            loop {
                // Register before inspecting credit, so completion or shutdown
                // between the check and await cannot be lost.
                let notified = self.inner.capacity.notified();
                tokio::pin!(notified);
                notified.as_mut().enable();
                match self.try_enqueue(&mut request)? {
                    Admission::Accepted(receiver) => {
                        if let Some(waiting) = &mut waiting {
                            waiting.admitted = true;
                        }
                        return Ok(receiver);
                    }
                    Admission::Full(_) => {
                        waiting.get_or_insert_with(|| AdmissionWait::new(self.inner.stats.clone()));
                        notified.await;
                    }
                }
            }
        }
        .await;
        self.record_rejection(&result);
        result
    }

    fn record_rejection<T>(&self, result: &Result<T>) {
        if result.is_err() {
            let mut stats = lock(&self.inner.stats);
            stats.rejected = stats.rejected.saturating_add(1);
        }
    }

    fn try_enqueue(&self, request: &mut Option<AdmittedWrite>) -> Result<Admission> {
        let admission = lock(&self.inner.admission);
        let sender = admission.as_ref().context("ingestion is closed")?;
        let input = request
            .as_ref()
            .expect("unadmitted input is owned by caller");
        let bytes = input.bytes();
        ensure!(
            input.rows() <= self.inner.config.max_group_rows
                && bytes.saturating_add(128) <= self.inner.config.max_group_bytes,
            "request exceeds ingestion group capacity"
        );
        ensure!(
            bytes <= self.inner.config.max_pending_bytes,
            "request exceeds ingestion pending byte budget"
        );
        let mut stats = lock(&self.inner.stats);
        if stats.pending_bytes.saturating_add(bytes) > self.inner.config.max_pending_bytes {
            return Ok(Admission::Full("ingestion pending byte budget exhausted"));
        }
        let (completion, receiver) = oneshot::channel();
        let pending = Pending {
            request: request.take(),
            completion: Some(completion),
            bytes,
            admitted: Instant::now(),
            stats: self.inner.stats.clone(),
            capacity: self.inner.capacity.clone(),
        };
        stats.pending_requests += 1;
        stats.pending_bytes += bytes;
        match sender.try_send(Command::Write(pending)) {
            Ok(()) => {
                stats.submitted = stats.submitted.saturating_add(1);
                stats.peak_pending_requests =
                    stats.peak_pending_requests.max(stats.pending_requests);
                stats.peak_pending_bytes = stats.peak_pending_bytes.max(stats.pending_bytes);
                Ok(Admission::Accepted(receiver))
            }
            Err(error) => {
                stats.pending_requests -= 1;
                stats.pending_bytes -= bytes;
                let (pending, full) = match error {
                    TrySendError::Full(pending) => (pending, true),
                    TrySendError::Disconnected(pending) => (pending, false),
                };
                let Command::Write(mut pending) = pending else {
                    unreachable!("write admission command")
                };
                *request = pending.request.take();
                pending.completion.take();
                if full {
                    Ok(Admission::Full("ingestion queue is full"))
                } else {
                    Err(anyhow!("ingestion worker is unavailable"))
                }
            }
        }
    }

    /// Enqueue a FIFO barrier, forcing a pending partial group to publish without
    /// waiting for its batching deadline. The receiver completes after preceding
    /// writes have terminal results; inspect `failed` as well as individual receipts.
    /// This does not checkpoint/evict hot rows or acknowledge remote durability.
    /// Queue-full/closed errors mean the barrier was not enqueued.
    pub fn flush(&self) -> Result<oneshot::Receiver<Result<IngestFlush>>> {
        let admission = lock(&self.inner.admission);
        let sender = admission.as_ref().context("ingestion is closed")?;
        let (completion, receiver) = oneshot::channel();
        sender
            .try_send(Command::Flush(completion))
            .map_err(|error| match error {
                TrySendError::Full(_) => anyhow!("ingestion queue is full"),
                TrySendError::Disconnected(_) => anyhow!("ingestion worker is unavailable"),
            })?;
        Ok(receiver)
    }

    /// Closes admission across all clones, drains accepted requests, then joins.
    /// This blocks; async callers should invoke it through spawn_blocking.
    pub fn shutdown(&self) -> Result<()> {
        self.inner.shutdown()
    }
    pub fn stats(&self) -> IngestStats {
        lock(&self.inner.stats).clone()
    }
    /// Snapshot of diagnostic history, not a durable log. Old records may be evicted.
    pub fn traces(&self) -> IngestTraceSnapshot {
        lock(&self.inner.traces).snapshot()
    }
}

fn consume(
    db: Database,
    receiver: Receiver<Command>,
    config: IngestConfig,
    stats: Arc<Mutex<IngestStats>>,
    traces: Arc<Mutex<TraceBuffer>>,
    capacity: Arc<Notify>,
) {
    let mut carry = None;
    loop {
        let first = match carry.take().or_else(|| receiver.recv().ok()) {
            Some(Command::Write(first)) => first,
            Some(Command::Flush(completion)) => {
                capacity.notify_waiters();
                finish_flush(&db, &stats, completion);
                continue;
            }
            None => break,
        };
        capacity.notify_waiters();
        let deadline = first.admitted + config.max_delay;
        let mut bytes = 128 + first.bytes;
        let mut rows = first.request.as_ref().unwrap().rows();
        let mut group = vec![first];
        let mut flush = None;
        while group.len() < config.max_group_requests
            && rows < config.max_group_rows
            && bytes < config.max_group_bytes
        {
            // An expired deadline forbids waiting, not coalescing an already
            // queued backlog. Otherwise a slow fsync degenerates into one fsync
            // per stale queued request precisely when batching is most needed.
            let wait = deadline.saturating_duration_since(Instant::now());
            let next = match receiver.recv_timeout(wait) {
                Ok(Command::Write(next)) => next,
                Ok(Command::Flush(completion)) => {
                    capacity.notify_waiters();
                    flush = Some(completion);
                    break;
                }
                Err(_) => break,
            };
            capacity.notify_waiters();
            let next_rows = next.request.as_ref().unwrap().rows();
            if bytes.saturating_add(next.bytes) > config.max_group_bytes
                || rows.saturating_add(next_rows) > config.max_group_rows
            {
                carry = Some(Command::Write(next));
                break;
            }
            rows += next_rows;
            bytes += next.bytes;
            group.push(next);
        }
        let requests = group
            .iter_mut()
            .map(|pending| Ok(pending.request.take().unwrap()))
            .collect();
        let started = Instant::now();
        let run = || {
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                db.write_admitted_group(requests)
            }))
        };
        let (outcome, phases) = if config.trace_capacity > 0 {
            db.inner.metrics.capture(run)
        } else {
            (run(), Vec::new())
        };
        let group_id = {
            let mut stats = lock(&stats);
            stats.groups = stats.groups.saturating_add(1);
            stats.groups
        };
        if config.trace_capacity > 0 {
            let ns = |duration: Duration| u64::try_from(duration.as_nanos()).unwrap_or(u64::MAX);
            let mut sequences = Vec::new();
            let mut failed = group.len();
            let mut duplicate = 0;
            if let Ok(results) = &outcome {
                failed = results.iter().filter(|result| result.is_err()).count();
                for receipt in results.iter().filter_map(|result| result.as_ref().ok()) {
                    sequences.push(receipt.sequence);
                    duplicate += usize::from(receipt.duplicate);
                }
            }
            sequences.sort_unstable();
            sequences.dedup();
            lock(&traces).push(IngestTrace {
                group: group_id,
                requests: group.len(),
                rows,
                oldest_queue_ns: ns(started.duration_since(group.first().unwrap().admitted)),
                newest_queue_ns: ns(started.duration_since(group.last().unwrap().admitted)),
                service_ns: ns(started.elapsed()),
                sequences,
                failed,
                duplicate,
                phases,
            });
        }
        match outcome {
            Ok(results) if results.len() == group.len() => {
                for (pending, result) in group.iter_mut().zip(results) {
                    pending.finish(result);
                }
            }
            _ => {
                for pending in &mut group {
                    pending.finish(Err(anyhow!(
                        "ingestion group failed unexpectedly; retry the same request ID"
                    )));
                }
            }
        }
        if let Some(completion) = flush {
            finish_flush(&db, &stats, completion);
        }
    }
}

fn finish_flush(
    db: &Database,
    stats: &Mutex<IngestStats>,
    completion: oneshot::Sender<Result<IngestFlush>>,
) {
    // No ingestion stats/admission lock is held while taking database state.
    let result = db.committed_sequence().map(|sequence| {
        let stats = lock(stats);
        IngestFlush {
            sequence,
            completed: stats.completed,
            succeeded: stats.succeeded,
            failed: stats.failed,
        }
    });
    let _ = completion.send(result);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Config, Row, TableConfig};

    fn test_request(id: usize) -> WriteRequest {
        WriteRequest {
            table: "metrics".into(),
            request_id: format!("r{id}"),
            now_us: 0,
            rows: vec![Row {
                timestamp_us: 0,
                tenant: "t".into(),
                series: "s".into(),
                value: 1.0,
                tags: Default::default(),
            }],
        }
    }

    fn manual_queue(bytes: usize) -> (Ingestor, Receiver<Command>) {
        let (sender, receiver) = bounded(1);
        (
            Ingestor {
                inner: Arc::new(Owner {
                    admission: Mutex::new(Some(sender)),
                    worker: Mutex::new(None),
                    config: IngestConfig {
                        max_pending_bytes: bytes,
                        ..Default::default()
                    },
                    stats: Arc::new(Mutex::new(IngestStats::default())),
                    traces: Arc::new(Mutex::new(TraceBuffer::new(0))),
                    capacity: Arc::new(Notify::new()),
                }),
            },
            receiver,
        )
    }

    fn poll_once<F: std::future::Future>(
        future: std::pin::Pin<&mut F>,
    ) -> std::task::Poll<F::Output> {
        future.poll(&mut std::task::Context::from_waker(std::task::Waker::noop()))
    }

    #[test]
    fn waiting_admission_preserves_input_and_credit_across_queue_and_byte_pressure() {
        for byte_pressure in [false, true] {
            let bytes = AdmittedWrite::new(test_request(0)).unwrap().bytes();
            let (ingest, queue) = manual_queue(if byte_pressure { bytes } else { 4 * bytes });
            let first = ingest.submit(test_request(0)).unwrap();
            let mut waiting = Box::pin(ingest.submit_wait(test_request(1)));
            assert!(poll_once(waiting.as_mut()).is_pending());
            assert_eq!(ingest.stats().waiting_requests, 1);
            assert_eq!(ingest.stats().submitted, 1);
            let Command::Write(mut pending) = queue.recv().unwrap() else {
                unreachable!()
            };
            ingest.inner.capacity.notify_waiters();
            if byte_pressure {
                // Dequeue alone cannot release in-flight byte credit.
                assert!(poll_once(waiting.as_mut()).is_pending());
                pending.finish(Err(anyhow!("explicit test completion")));
            }
            let std::task::Poll::Ready(Ok(second)) = poll_once(waiting.as_mut()) else {
                panic!("released credit must admit")
            };
            let Command::Write(mut next) = queue.recv().unwrap() else {
                unreachable!()
            };
            assert_eq!(next.request.as_ref().unwrap().rows(), 1);
            next.finish(Err(anyhow!("explicit test completion")));
            pending.finish(Err(anyhow!("explicit test completion")));
            assert!(first.blocking_recv().unwrap().is_err());
            assert!(second.blocking_recv().unwrap().is_err());
            let stats = ingest.stats();
            assert_eq!(stats.submitted, 2);
            assert_eq!(stats.rejected, 0);
            assert_eq!(stats.admission_waits, 1);
            assert_eq!(stats.waiting_requests, 0);
            assert_eq!(stats.waits_without_admission, 0);
            assert_eq!(stats.pending_bytes, 0);
        }
    }

    #[test]
    fn waiting_cancellation_and_shutdown_never_enqueue_the_unadmitted_input() {
        for shutdown in [false, true] {
            let bytes = AdmittedWrite::new(test_request(0)).unwrap().bytes();
            let (ingest, queue) = manual_queue(bytes);
            let first = ingest.submit(test_request(0)).unwrap();
            let mut waiting = Box::pin(ingest.submit_wait(test_request(1)));
            assert!(poll_once(waiting.as_mut()).is_pending());
            if shutdown {
                ingest.shutdown().unwrap();
                let std::task::Poll::Ready(Err(error)) = poll_once(waiting.as_mut()) else {
                    panic!("shutdown must wake admission")
                };
                assert!(error.to_string().contains("closed"));
            }
            drop(waiting);
            let Command::Write(mut pending) = queue.recv().unwrap() else {
                unreachable!()
            };
            pending.finish(Err(anyhow!("explicit test completion")));
            assert!(first.blocking_recv().unwrap().is_err());
            assert!(queue.try_recv().is_err());
            let stats = ingest.stats();
            assert_eq!(stats.submitted, 1);
            assert_eq!(stats.completed, 1);
            assert_eq!(stats.waiting_requests, 0);
            assert_eq!(stats.waits_without_admission, 1);
            assert_eq!(stats.rejected, u64::from(shutdown));
            assert_eq!(stats.pending_bytes, 0);
        }
    }

    #[test]
    fn impossible_waiting_request_is_rejected_without_waiting() {
        let bytes = AdmittedWrite::new(test_request(0)).unwrap().bytes();
        let (ingest, _queue) = manual_queue(bytes - 1);
        let mut waiting = Box::pin(ingest.submit_wait(test_request(0)));
        assert!(matches!(
            poll_once(waiting.as_mut()),
            std::task::Poll::Ready(Err(_))
        ));
        let stats = ingest.stats();
        assert_eq!(stats.admission_waits, 0);
        assert_eq!(stats.rejected, 1);
        assert_eq!(stats.submitted, 0);
    }

    #[test]
    fn flush_barriers_share_the_bounded_queue_without_row_credit() {
        let (sender, receiver) = bounded(1);
        let ingest = Ingestor {
            inner: Arc::new(Owner {
                admission: Mutex::new(Some(sender)),
                worker: Mutex::new(None),
                config: IngestConfig::default(),
                stats: Arc::new(Mutex::new(IngestStats::default())),
                traces: Arc::new(Mutex::new(TraceBuffer::new(0))),
                capacity: Arc::new(Notify::new()),
            }),
        };
        let mut first = ingest.flush().unwrap();
        assert!(
            ingest
                .flush()
                .unwrap_err()
                .to_string()
                .contains("queue is full")
        );
        assert_eq!(ingest.stats().pending_requests, 0);
        assert_eq!(ingest.stats().pending_bytes, 0);
        drop(receiver);
        // Crossbeam retains queued payloads until both channel sides are gone.
        assert!(matches!(
            first.try_recv(),
            Err(oneshot::error::TryRecvError::Empty)
        ));
        assert!(
            ingest
                .flush()
                .unwrap_err()
                .to_string()
                .contains("unavailable")
        );
        ingest.shutdown().unwrap();
        assert!(matches!(
            first.try_recv(),
            Err(oneshot::error::TryRecvError::Closed)
        ));
        assert!(ingest.flush().unwrap_err().to_string().contains("closed"));
    }

    #[test]
    fn expired_deadline_still_coalesces_ready_backlog() {
        let temp = tempfile::TempDir::new().unwrap();
        let db = Database::open(temp.path(), Config::default()).unwrap();
        db.create_table("metrics", TableConfig::default()).unwrap();
        let (sender, receiver) = bounded(4);
        let stats = Arc::new(Mutex::new(IngestStats::default()));
        let mut completions = Vec::new();
        for id in 0..4 {
            let request = WriteRequest {
                table: "metrics".into(),
                request_id: format!("r{id}"),
                now_us: 0,
                rows: vec![Row {
                    timestamp_us: 0,
                    tenant: "t".into(),
                    series: "s".into(),
                    value: 1.0,
                    tags: Default::default(),
                }],
            };
            let bytes = request.admission_bytes().unwrap();
            let (completion, receive) = oneshot::channel();
            completions.push(receive);
            lock(&stats).pending_requests += 1;
            lock(&stats).pending_bytes += bytes;
            sender
                .send(Command::Write(Pending {
                    request: Some(AdmittedWrite::new(request).unwrap()),
                    completion: Some(completion),
                    bytes,
                    admitted: Instant::now(),
                    stats: stats.clone(),
                    capacity: Arc::new(Notify::new()),
                }))
                .unwrap();
        }
        drop(sender);
        consume(
            db.clone(),
            receiver,
            IngestConfig {
                max_delay: Duration::ZERO,
                max_group_requests: 4,
                ..Default::default()
            },
            stats.clone(),
            Arc::new(Mutex::new(TraceBuffer::new(0))),
            Arc::new(Notify::new()),
        );
        let receipts: Vec<_> = completions
            .into_iter()
            .map(|c| c.blocking_recv().unwrap().unwrap())
            .collect();
        assert!(receipts.iter().all(|r| r.sequence == receipts[0].sequence));
        assert_eq!(lock(&stats).groups, 1);
        assert_eq!(lock(&stats).pending_bytes, 0);
        assert_eq!(db.status().unwrap().hot_rows, 4);
    }
}

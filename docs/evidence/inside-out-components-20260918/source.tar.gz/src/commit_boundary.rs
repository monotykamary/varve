//! Private touched-delta ownership across the durable append boundary.
use super::*;

pub(super) struct PendingAppend {
    appends: Vec<PreparedAppend>,
    floors: BTreeMap<String, Option<i64>>,
    // Detached resident growth is not spare capacity for concurrent snapshots.
    // Transfer its charge into working until installation restores resident.
    _resident_growth: DerivedWorking,
}

impl PendingAppend {
    /// Move forward values out while restoring the committed baseline. No row,
    /// aggregate, table or catalog clone is needed. Reverse order matters when
    /// multiple requests touch the same group in a physical WAL epoch.
    pub(super) fn detach(
        s: &mut State,
        undo: &mut Vec<AppendUndo>,
        floors_before: &BTreeMap<String, Option<i64>>,
    ) -> Self {
        let staged_resident = s.derived_resident_bytes;
        let floors = floors_before
            .keys()
            .map(|name| (name.clone(), s.idempotency_floors.get(name).copied()))
            .collect();
        let mut appends = Vec::with_capacity(undo.len());
        for entry in undo.drain(..).rev() {
            let table = s
                .catalog
                .tables
                .get_mut(&entry.table)
                .expect("staged table");
            let receipt = table
                .receipts
                .remove(&entry.request_id)
                .expect("staged receipt");
            let mut updates = BTreeMap::new();
            for (key, previous) in entry.rollups {
                let row = if let Some(previous) = previous {
                    table
                        .rollups
                        .insert(key.clone(), previous)
                        .expect("staged rollup")
                } else {
                    let row = table.rollups.remove(&key).expect("staged rollup");
                    s.rollup_indexes
                        .get_mut(&entry.table)
                        .expect("staged index")
                        .remove(&key, &row);
                    row
                };
                updates.insert(key, row);
            }
            let batch = s
                .hot
                .get_mut(&entry.table)
                .expect("staged hot table")
                .pop()
                .expect("staged batch");
            if entry.hot_len.is_none() {
                s.hot.remove(&entry.table);
            }
            let accounting = s
                .derived_accounting
                .replace(entry.table.clone(), entry.derived_accounting)
                .expect("staged accounting");
            appends.push(PreparedAppend {
                table: entry.table,
                request_id: entry.request_id,
                receipt,
                updates,
                batch,
                bytes: s.hot_bytes - entry.hot_bytes,
                metadata_bytes: s.metadata_bytes,
                derived: DerivedAppend {
                    working: entry._derived_working,
                    resident: s.derived_resident_bytes,
                    accounting,
                },
            });
            s.hot_bytes = entry.hot_bytes;
            s.metadata_bytes = entry.metadata_bytes;
            s.derived_resident_bytes = entry.derived_resident_bytes;
        }
        appends.reverse();
        restore_group_floors(s, floors_before);
        let bytes = staged_resident.saturating_sub(s.derived_resident_bytes);
        s.derived_working.fetch_add(bytes, Ordering::SeqCst);
        let resident_growth = DerivedWorking {
            counter: Arc::clone(&s.derived_working),
            bytes,
        };
        Self {
            appends,
            floors,
            _resident_growth: resident_growth,
        }
    }

    /// The commit gate has excluded all structural and append writers since
    /// detach. Readers may have changed caches/pins, which we never replace.
    /// Everything below is prevalidated: no fallible replay after durability.
    pub(super) fn install(self, s: &mut State) {
        for prepared in self.appends {
            s.raw_stamps
                .insert(prepared.table.clone(), fresh_raw_stamp());
            let index = s.rollup_indexes.entry(prepared.table.clone()).or_default();
            for (key, row) in &prepared.updates {
                index
                    .insert(key, row, usize::MAX)
                    .expect("prevalidated rollup index");
            }
            let table = s
                .catalog
                .tables
                .get_mut(&prepared.table)
                .expect("prepared table");
            table.rollups.extend(prepared.updates);
            table.receipts.insert(prepared.request_id, prepared.receipt);
            s.hot
                .entry(prepared.table.clone())
                .or_default()
                .push(prepared.batch);
            s.hot_bytes += prepared.bytes;
            s.metadata_bytes = prepared.metadata_bytes;
            s.derived_resident_bytes = prepared.derived.resident;
            s.derived_accounting
                .replace(prepared.table, prepared.derived.accounting);
        }
        restore_group_floors(s, &self.floors);
    }
}

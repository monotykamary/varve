# Architecture

The server currently implements the architecture below. The [inside-out rebuild](INSIDE_OUT_REBUILD.md) defines its replacement and separates completed component proofs from pending production integration; the new `flow` and `journal` modules are not yet the server write path.

## Scope

Varve v0.1 is a single-node modular Rust database for append-only numeric time-series measurements. Named tables have fixed typed rows: signed UTC epoch `timestamp_us`, `tenant`, `series`, finite f64 `value`, and ordered string `tags`. Table settings select hash shards, event-time windows, lateness, raw retention, archive age and continuous-aggregate widths. A committed global sequence and row ordinal break equal-timestamp ties. A timestamp/series pair is not unique; request IDs deduplicate entire batches.

## Write and recovery path

1. Admit caller-owned rows into a private immutable input. Validate static row/ID properties once, carry its byte charge through the queue, and stream the exact canonical row digest/length without allocating a JSON payload. Then lock state to validate the current table, timestamps, cutoffs, budgets, clocks and conflicts.
2. Precompute affected aggregate groups. Bound their working set and projected encoded metadata, including future segment-reference reservations. Check hot/WAL/disk budgets and checkpoint first when necessary.
3. Encode the existing versioned/checksummed immutable WAL frame. Direct writes retain legacy `Append`; the bounded coordinator combines requests into `AppendGroup` epochs with per-request receipts and one physical sequence. Prepare under the writer/structural gate, detach touched forward values into private ownership and restore the committed state before releasing its mutex. Pending derived resident growth remains reserved.
4. Write the complete WAL temporary under disk admission, then release disk and reader-state locks for file sync. Reacquire disk admission for the short atomic rename, and release it again for directory sync; error-path temporary cleanup also takes admission. Guarded directory accounting therefore includes the whole pending frame without racing its namespace transitions. The writer/structural gate prevents conflicting publication and GC. After durability, install the prevalidated private delta atomically under state and only then acknowledge `local_fsync`. Readers can observe the prior committed raw/derived/receipt snapshot during append fsync, never provisional rows.

HTTP and WebSocket writes share one bounded Crossbeam coordinator. Request/row/byte/time ceilings bound each epoch; pending bytes include queued and in-flight work. `Ingestor::flush` adds a bounded FIFO drain barrier, completing prior requests without forcing columnarization or memory eviction. Its result reports cumulative successes and failures; admission is never an early durability acknowledgment. The direct/grouped path uses touched undo/forward values rather than a full catalog clone. Checkpoint-capable retry restores committed state and releases the writer gate before unlocked preparation; ambiguous WAL failures fence instead of retrying publication. Root/control fsync and synchronous fallback maintenance can still hold state. Global sequence/ordinal ties, timed-ID floors, exact float persistence, independent recovery validation and fail-closed corruption remain authoritative. See [BOUNDARY_REDESIGN.md](BOUNDARY_REDESIGN.md) for current qualification, not a production or lock-free claim.

Live preparation borrows its immutable validated input; bounded checkpoint retries do not move rows into and back out of a temporary WAL record. Typed borrowed encoding is byte-identical to the old owned record. Recovery has a separate validating constructor and rechecks every inner row digest and static property; no trusted flag accepts decoded WAL. Stored-row conversion and final WAL encoding still allocate and perform work.

Append admission streams exact touched receipt/rollup JSON sizes into one private scalar projection shared by logical metadata and derived accounting. This is not a retained map cache: the projection belongs to the exact locked state and is recomputed after checkpoint-capable preparation, including same-sequence receipt/floor changes. Existing admission order, conservative bounds, working reservations and corruption/durability checks remain authoritative.

An exclusive OS file lock enforces one process per data directory. Startup removes recognized unpublished temporaries, loads the verified manifest and replays exactly the contiguous WAL tail above its checkpoint. Committed corruption, unknown formats and sequence gaps fail closed. Idempotency receipts are independent of raw expiration. Legacy receipts remain durable; opted-in timed-ID windows atomically prune receipts with a monotonic rejection floor at checkpoint, so old retries cannot silently reinsert data.

## Checkpoints and snapshots

The checkpoint root atomically commits table definitions, segment references, derived state, request receipts, rejection/retention cutoffs and replay position. Legacy v1 stores derived maps inline; explicitly enabled v2 references separate immutable rollup/receipt page sets at the same frontier. Both remain readable, and v2 never silently downgrades. Checkpointing syncs raw and derived dependencies, publishes the complete root, then retires the covered uncheckpointed designation/WAL. With retained inputs enabled, exact checkpoint chunks that fit the decoded cache are offered to its bounded LRU; a durable checkpoint is not itself a serving-eviction requirement. Compaction replaces references, never query-visible state piecemeal. Unreferenced output is garbage, not committed data. See [DERIVED_STATE.md](DERIVED_STATE.md).

Hot state uses immutable, logically charged row batches. Default SQL snapshots flatten selected rows; explicitly retained SQL snapshots share batch `Arc`s, copy bounded view state and pin needed immutable file identities. A selected checkpointed segment contributes either its resident rows or its Parquet file, never both. Compaction/expiration can publish replacement manifests while existing queries keep their old files. Cache eviction skips only pinned entries, not the entire cache. Per-file decoded-size metadata is checked before Parquet allocation/decompression. Current manifest segment references require positive decoded-size estimates. Lower-level decode/query adapters must conservatively bound unknown estimates, never count them as free; this is not automatic migration of roots missing required decoded-size metadata.

With `checkpoint_frozen_prefix=true`, a checkpoint captures a durable prefix through N and prepares it outside state while ordinary appends may reach M. Publication validates root/control epochs and idempotency floors, retains live aggregates/receipts/accounting at M, and retires only the covered hot designation and WAL through N. The uncheckpointed tail keeps its admission age; an unknown legacy age is conservatively due. Structural changes invalidate the candidate rather than being overwritten. The shared direct/grouped commit path gets at most one off-lock checkpoint retry; same-frontier receipt reclamation counts as progress when a new durable root was published. Direct admission uses exact hot-row charges rather than the conservative group envelope. The default exact-stamp protocol is unchanged. See [INGESTION.md](INGESTION.md).

Dependency preparation owns pins through a typed pending-to-durable guard. Files are verified or written and file-synced under disk admission, then required directory barriers are coalesced before a root can be constructed. Existing objects are re-synced rather than assuming a preceding failed publisher completed durability. Raw batches finish per partition-writing invocation; derived pages finish per root preparation. Neither WAL nor root acknowledgement barriers are removed.

Prepared checkpoint/compaction dependency work, derived encoding and replacement-index construction run outside state; capture, root fsync, namespace retirement/accounting and synchronous control/admission fallbacks still serialize with commits. Frozen-prefix publication releases state and writer gates before the obsolete-WAL directory barrier and private destruction, while retaining preparation ownership and pins through completion. Other GC/control paths are not made nonblocking by that change. Remote publication uses a distinct operation gate and frozen, pinned dependencies; network uploads do not need to hold the ingestion state lock. See the remote tests and due-diligence record for the exercised slow-store boundary. No lock-free or hard-latency claim is made.

## Physical partitioning and tiers

`shard_for(tenant, series, shard_count)` is length-prefixed FNV-1a with pinned golden vectors. Event windows use Euclidean floor division, including negative epochs. Files are grouped by table/shard/window and sorted by tenant, series, timestamp, sequence and ordinal; their hashes, sizes, row counts and bounds are in the manifest. Shards are physical partitioning/routing units, not separately replicated distributed owners in this version. Table settings are immutable.

CPU caches are hardware managed. Varve uses batching and sorted columnar layouts, not fictional L1/L2 durability tiers. RAM holds recent rows plus a bounded decoded cache; disk holds WAL, current Parquet and bounded downloaded cold files. S3-compatible storage provides optional asynchronous recovery/archive backing. Filesystem object storage implements the same protocol for hermetic tests.

## Derived state and lifecycle

Rollup keys are `(table, width, bucket, tenant, series, tags)`. Updates maintain count, sum, min, max and event-time first/last; average derives from sum/count and OHLC aliases first/max/min/last. Raw and derived changes share a WAL operation and checkpoint. This is constrained continuous aggregation, not general SQL incremental maintenance or a planner that substitutes rollups for raw SQL automatically.

Scheduler ticks drive age/size flush, small-file compaction, remote publication, protected local eviction, raw expiration, aggregate expiration and garbage collection. The maintenance interval does not override the configured flush interval: both state-lock phases recheck current hot age and retention requirements. Compaction prefetch and execution share metadata-only selection rules; no-op ticks avoid full-catalog clones. Execution pins selected inputs under disk admission and defers newly eligible cold groups until the next unlocked prefetch instead of GETting under state. Cutoffs are monotonic and persisted. Raw expiration can filter partial files, reclaim fully obsolete files, and preserve independently retained derived history. These rollups are historical summaries, not necessarily strict views of only the remaining raw rows.

## Remote publication

Immutable manifests/segments/WAL have digest-derived keys. A conditional head publishes a complete checkpoint plus contiguous tail only after dependencies upload. A separate publication/GC gate prevents vacuum from deleting in-flight dependencies. Vacuum also protects current local catalog references and active per-object reader pins, sampled in state-to-pin lock order without holding those locks over network deletion. Remote CAS locks exclude restore and remote vacuum; locks fail closed on crashes and are never blindly time-stolen. Restore transfers ownership and verifies metadata/WAL immediately, then verifies cold segments on demand. See [REMOTE.md](REMOTE.md) for operational recovery and caveats.

A local acknowledgment is not an S3 acknowledgment. Losing the local disk can lose the unshipped tail; an interval cannot bound that gap during an outage. S3-compatible providers must support strong conditional writes. The adapter uses ordinary immutable objects, not an assumption that Express append provides multi-AZ durability.

## SQL boundary

The database owns a bounded pool of real DuckDB v2 CLI workers. Default/standalone queries retain fresh input materialization; explicitly enabled `query_retained_inputs` uses disposable typed tables. Native/direct scanners keep exact original-file allowlists and execution keys. Eligible retained workers have no original-file authority: captured, verified and pinned immutable files are imported through short-lived private aliases, removed before user SQL. Hot batches use typed Arrow/Parquet staging. Both paths copy data; this is not native embedding or zero-copy Arrow.

Selected-ID bindings separate the current query scope from bounded, charged inactive immutable batches. Complete live lineage and process-local per-table raw stamps are captured with the snapshot. A proven complete cached table can survive a checkpoint/cache/compaction representation change with the same logical stamp; append, retention, recreation or unproven replacement invalidates that proof or admits only proven additions. Raw stamps are not durable frontiers and never replace root/publication validation. Namespace, sequence, exact values, pins, budgets and transactional relation refresh remain required. Oversized cold selections conservatively fall back to the exact-file native scanner rather than rejecting valid cold SQL. Catalog/rollup payloads remain current, with schema-only catalog exposure only under the existing positive AST proof. See [QUERY_WORKERS.md](QUERY_WORKERS.md).

Startup files, extension autoload/install and spilling remain disabled. The default path still chooses bounded small typed SQL or copied NDJSON; retained raw inputs use copied Parquet and dynamic relations retain bounded typed/JSON transports. Memory/thread/worker/timeout/output limits are explicit, not a total-process RSS guarantee. No bundled C++ build is required.

A conservative SQL AST planner proves relation/time pruning for safe single-source queries, including derived-table chains whose predicates are taken only from the innermost source; complex/dynamic syntax falls back without guessing. SQL execution remains DuckDB's job. Read-only lexical guards are deliberately conservative, not an untrusted filesystem/network sandbox. EXPLAIN's CLI-rendered plans receive a JSON wrapper. See [QUERY.md](QUERY.md).

## Module boundaries

- `model.rs`: typed domain, validation, fixed routing and public configuration.
- `wal.rs` / `dependency_publication.rs`: durable frame encoding/publication and separately batched, pinned checkpoint dependencies.
- `write_input.rs`: immutable admission/preparation ownership and independent replay validation.
- `engine.rs`: state/admission, replay, checkpoints, coherent snapshots and native scans.
- `segment.rs`: reusable typed Arrow/Parquet read/write.
- `plan.rs` / `query.rs`: conservative exposure planning and replaceable SQL adapter.
- `remote.rs`: reusable synchronous RemoteStore abstraction, filesystem and AWS adapters, bounded object I/O.
- `tier.rs`: publication ownership, restore, remote locks and reachable-object vacuum.
- `policy.rs`: deterministic-clock lifecycle orchestration.
- `ingest.rs`: bounded many-producer queue, batching writer, completion receipts and drain.
- `service.rs` / `transport.rs` / `pg_transport.rs`: authenticated HTTP/WebSocket service and opt-in loopback SCRAM PostgreSQL-wire simple queries.
- `main.rs`: JSON CLI and service lifecycle.
- `clients/rust` / `clients/typescript`: independent network clients; no embedded storage dependency.

The interfaces are reusable without the HTTP server. Runtime/backend configuration, user-facing commands, tests and explicit production exclusions are linked from the README.

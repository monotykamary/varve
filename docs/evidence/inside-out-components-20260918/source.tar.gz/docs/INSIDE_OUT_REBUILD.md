# Inside-out rebuild

Status: architectural reset in progress, 2026-09-18. This document specifies the replacement, not what the current engine already implements. All compilation, executable tests, profiling and load generation for this campaign run on Railway. No local Cargo, Docker builds or benchmark fixtures.

## Original requirement

The original request was to make ordinary single inserts efficient through the Crossbeam/Disruptor approach: "ingest into a ring buffer to flush and saturate localized writes". Later clarifications emphasized hot-path accessibility, batching/checkpoints, locality/residency and no dropped data. A bounded channel in front of the old shared-state engine is not the end state.

Crossbeam supplies transport primitives, not persistence or broadcast dependencies. Cloned receivers distribute messages; they do not deliver every event to WAL, views and storage. A ring never overwrites outstanding work. Neither batching nor a queue proves an order-of-magnitude durable-throughput advantage.

## Replacement data plane

```text
persistent clients / batch API
    -> bounded credits + owned validated input
    -> sequenced microbatches
    -> partition-local preparation owners
           |-> sequential framed journal -> durable frontier D
           |-> private raw + derived preparation -> prepared frontier P
    -> coherent immutable publication through min(D, P)
    -> visible frontier V -> durable receipts

published immutable batches
    |-> native DuckDB snapshot scanners
    |-> checkpoint / Parquet / compaction workers
    |-> sealed journal segments + dependencies -> S3 publication
```

This is a dependency graph, not a thread per box. Begin with one journal/sequencing owner and bounded partition owners. Cross-partition requests require one atomic commit descriptor; completing one partition cannot acknowledge the request.

## Contracts

1. Admission is not success. A successful receipt remains durable, idempotent and query-visible with required aggregate updates. Cancellation before admission consumes no slot; dropping a receipt receiver after admission does not discard its write. Ambiguous I/O fences the writer.
2. Mutable commit state has an explicit owner. Readers pin immutable versions. Preparation returns private validated deltas instead of mutating and undoing committed maps. Publication references immutable partition versions rather than copying the entire database.
3. Frontiers are contiguous prefixes, not maximum observed sequence numbers: sequenced `S`, prepared `P`, locally synced `D`, visible `V <= min(D,P)`, checkpointed `C <= V`, remotely confirmed `R`. Rejected/cancelled slots require explicit terminal handling so they cannot strand progress.
4. Local completion requires durability and visibility. Any future object-store-confirmed mode also requires remote coverage. Local fsync is not S3 durability. No periodic upload interval bounds remote data loss during an outage.
5. Credits cover queued, preparing, in-flight, resident and pinned data. Ownership transfers charges; it never makes live memory free. Required consumers gate reclamation until work is consumed or transferred into separately charged storage. Deadlines and overload remain visible; no shedding or unsafe retry.
6. Shutdown closes admission, drains admitted work, completes terminal outcomes and joins owned workers. Native fsync can still extend shutdown; no false hard-timeout guarantee.

## Architectural replacements

### Journal

Replace per-group temporary-file/fsync/rename/directory-fsync publication with a versioned append-oriented segmented journal. Coalesce writes and sync by bounded row/byte/age limits. Creation, rotation and sealing retain namespace durability barriers; ordinary appends do not create a namespace transaction per group.

Define framing, checksums, commit markers, contiguous recovery, incomplete-tail handling, fencing, bounded replay and reclamation before enabling the format. Complete corrupt frames and interior gaps fail closed. Do not claim incomplete-tail handling can diagnose arbitrary post-acknowledgment hardware corruption. Sealed immutable segments are the S3 upload unit; publish remote heads only after dependencies upload. Old databases require an explicit migration/read-compatibility contract.

### Hot storage and SQL

Keep immutable typed batches resident across durable checkpoints when budgets allow. Durability, columnarization, eviction, archival and expiration are distinct transitions. Partition-local builders prepare data; published batches serve readers.

Replace CLI workers and copied shadow relations with native DuckDB scanners over pinned batches and verified Parquet. Verify the pinned v2 library/API identity first. Buffers and file pins outlive scans, interruption and teardown. Bound and measure unavoidable vector conversion; native is not automatically zero-copy. No per-query full relation materialization or hot-data staging file is the normal serving path. DuckDB executes SQL; it does not become Varve's primary storage engine.

Native execution changes failure isolation and resource containment. Interruption, joining, allocator limits and trusted-SQL boundaries require tests; embedding alone does not establish a process RSS or security guarantee.

### Views and lifecycle

View operators expose initialization, batch application, versioned read state, checkpoint and restore. Initial operators preserve current time-series aggregates, late arrivals and exact first/last tie rules. General SQL incremental maintenance needs explicitly supported forms and separate acceptance tests; renaming fixed rollups does not implement it.

Partition ownership follows identity and event time. Physical partitions are not automatically distributed writers. Maintenance prepares immutable replacements off-owner, then submits version-checked publication. Slow S3 upload reads sealed disk segments rather than holding hot-ring slots indefinitely; bounded unshipped disk eventually backpressures ingestion.

Reusable boundaries: admission/sequencing, journal, partition state/snapshots, view operators, lifecycle/object storage and SQL scanners. Separate crates only for real independently testable contracts, not cosmetic file movement.

## Acceptance ledger

Preserve dirty work, existing client/wire contracts and independent recovery/data oracles. Do not overwrite existing deployments, volumes, bucket namespaces, historical evidence or old campaign approvals.

| Gate | Required evidence | State |
| --- | --- | --- |
| R0 | Original intent recovered; isolated cloud-only qualification workflow | passed for this checkpoint: pinned Rust 1.98.1, source-only transfer, all executable work on Railway |
| R1 | Owner/sequencer path wired end to end; credits, barriers, coherent publication, cancellation and shutdown | replacement component: 12 flow tests, bounded memory model and 4,096 exact receipts/replay pass; production engine integration pending |
| R2 | Segmented journal wired to commit/recovery; crash/corruption matrix, format and migration contract | replacement journal: 22 tests and real pipeline/rotation/reopen proof pass; legacy engine wiring, checkpoint reclamation and migration pending |
| R3 | Native scanners wired to public SQL; exact hot/cold/view results, cancellation/pins/bounds, no hot-input staging | pinned-library Stage A ABI/projection/caller-buffer/destructor proof passed on Railway; Rust adapter and full SQL qualification pending |
| R4 | Versioned view/lifecycle interfaces; late data, retention and snapshots across checkpoints/compaction | pending |
| R5 | Persistent single-row and batched clients; no missing work; exact raw/derived/restart/idempotency oracles on Railway | pending |
| R6 | Matched-resource/durability Timescale comparison: ingestion, fresh views, useful analytics, maintenance and intended-arrival tails | pending |
| R7 | Coherent source review, binary identity, migration/rollback; remove superseded paths only after acceptance | pending |

Ordinary single-row traffic is mandatory. Batch-1000-only results cannot substantiate the original request. Report admission, durable completion and fresh visibility separately. Count backlog/drain and checkpoint cycles; measure CPU, peak memory and disk amplification. Failed or ambiguous runs remain failed evidence. Native integration and segmented WAL are hypotheses, not guaranteed Timescale wins.

## First component checkpoint

New public modules `flow` and `journal` replace two architectural mechanisms in isolation. The executable `examples/flow_journal_probe.rs` connects them to private preparation and immutable publication. It is intentionally not relabeled as a server, a time-series implementation, or a throughput benchmark.

The corrected Railway proof offered 4,096 individual events from four producers with 16 outstanding requests each. All 4,096 completed after durable visibility and reopened with exact independent identities. They formed 128 journal groups across six segments, with six namespace barriers rather than one per request/group. The encoded journal was 82,624 bytes; final ring credits were zero. Group counts are workload/scheduling observations, not a sustained-rate result.

Review found three real flow issues: stale peer-frontier inspection could miss reclamation, an ineligible blocking waiter could swallow another producer's wake, and coalescing could acquire more work after fencing. Two deterministic actual regressions failed before correction. The independent-completion memory model witnesses the old weak-memory counterexample and checks the corrected lock-before-inspection protocol with preemption bound two. It is not a model of the full queue or storage stack. Corrected real-thread tests, component proof, strict Clippy and formatting passed remotely. No correctness certificate or production readiness is inferred.

The prior unfinished rollup test also passed remotely. Of 52 baseline query tests, one initially failed because DuckDB was missing from PATH; that exact case passed after the environment correction. All nine baseline ingestion integration tests passed. Historical failure logs remain evidence, not silently rewritten successes.

Remaining major replacements are explicit: actual engine ownership/public API wiring, raw/derived/receipt state and idempotency on the journal, checkpoint reclamation and migration, native Rust scanners and JSON/cancellation/pinning parity, object-store publication, lifecycle integration, then matched Timescale workloads. The current running app has not been migrated.

## Cloud ownership and resource limits

Campaign: `varve-inside-out-20260918`.
Project: `8caffa15-0158-4822-a6c2-cb405bddc62d` (`varve-evaluation`).
Environment: `5ec35c82-c1ea-4aa4-b7a5-b89e4c4b9ed1`.
Initial sandbox: `d61734d7-61eb-4658-aa85-bae3a52e6373`, 15-minute idle timeout, no private network, service variables or production credentials. This is qualification compute, not a matched-resource benchmark backend.

Only lightweight source operations run locally. Stream source-only archives, excluding `.git`, `target`, dependency trees, credentials, database data and old evidence. Bound remote Cargo jobs, fixture sizes and command timeouts. Retain one build cache and compact source-bound results. Destroy owned sandboxes at task end; idle expiry is a backstop, not proof of cleanup. Existing production and benchmark services remain untouched.

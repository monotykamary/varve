use super::*;
use std::collections::BTreeMap;
use std::sync::Weak;

#[cfg(test)]
#[path = "resident_tests.rs"]
mod tests;

type BatchKey = (String, String);

pub(super) struct ResidentRequest<'a> {
    snapshot: &'a ResidentSnapshot,
    tables: &'a [QueryTable],
    catalog: &'a QueryCatalog,
    setup: String,
    batches: BTreeMap<BatchKey, &'a ResidentBatch>,
    metadata_bytes: usize,
}

impl<'a> ResidentRequest<'a> {
    pub(super) fn new(
        tables: &'a [QueryTable],
        snapshot: &'a ResidentSnapshot,
        options: &QueryOptions,
        catalog: &'a QueryCatalog,
        deadline: Instant,
        cancelled: &AtomicBool,
    ) -> Result<Self> {
        ensure!(
            tables.iter().all(|table| table.hot.is_empty()),
            "resident query requires empty QueryTable.hot"
        );
        ensure!(
            tables.len() == snapshot.tables.len(),
            "resident table scope mismatch"
        );
        let mut metadata_bytes = snapshot.namespace.len();
        let mut names = HashSet::new();
        let mut batches = BTreeMap::new();
        for table in &snapshot.tables {
            check_deadline(deadline, cancelled)?;
            ensure!(
                names.insert(&table.name)
                    && tables.iter().any(|selected| selected.name == table.name),
                "resident table scope mismatch"
            );
            metadata_bytes = charge(metadata_bytes, table.name.len().saturating_add(256))?;
            for batch in &table.batches {
                check_deadline(deadline, cancelled)?;
                // Charge even empty batches, including owned keys and tree/Weak bookkeeping.
                metadata_bytes = charge(
                    metadata_bytes,
                    batch
                        .id
                        .len()
                        .saturating_add(table.name.len())
                        .saturating_add(256),
                )?;
                ensure!(
                    batches
                        .insert((table.name.clone(), batch.id.clone()), batch)
                        .is_none(),
                    "duplicate resident batch identity"
                );
            }
        }
        let empty_tables: Vec<_> = tables
            .iter()
            .map(|table| QueryTable {
                name: table.name.clone(),
                hot: vec![],
                files: table.files.clone(),
                rollups: vec![],
                cutoff_us: table.cutoff_us,
            })
            .collect();
        let empty_catalog = QueryCatalog {
            relations: catalog
                .relations
                .iter()
                .map(|relation| CatalogRelation {
                    name: relation.name.clone(),
                    columns: relation.columns.clone(),
                    rows: vec![],
                })
                .collect(),
            aggregates: catalog.aggregates.clone(),
        };
        let (setup, input) = build_query_mode(
            &empty_tables,
            "",
            options,
            &empty_catalog,
            Path::new("."),
            false,
        )?;
        debug_assert!(input.is_empty());
        let (_, setup) = setup
            .split_once("CREATE TEMP TABLE __varve_version_gate")
            .context("missing resident version gate")?;
        let setup = format!("CREATE TEMP TABLE __varve_version_gate{setup}");
        ensure!(
            setup.len() <= MAX_QUERY_SCRIPT_BYTES,
            "resident schema exceeds SQL script limit"
        );
        metadata_bytes = charge(metadata_bytes, setup.len())?;
        Ok(Self {
            snapshot,
            tables,
            catalog,
            setup,
            batches,
            metadata_bytes,
        })
    }
}

struct LoadedBatch {
    // Weak identity detects remapped IDs without retaining the engine's row allocations.
    // A new Arc for identical bytes conservatively misses; float PartialEq is never used.
    rows_identity: Weak<Vec<StoredRow>>,
    rows: usize,
    bytes: usize,
    charged_bytes: usize,
}

pub(super) struct ResidentState {
    namespace: String,
    sequence: u64,
    setup: String,
    batches: BTreeMap<BatchKey, LoadedBatch>,
    dynamic: Vec<u8>,
    pub(super) rows: usize,
    pub(super) bytes: usize,
}

impl ResidentState {
    pub(super) fn compatible(&self, request: &ResidentRequest<'_>) -> bool {
        self.namespace == request.snapshot.namespace
            && self.sequence <= request.snapshot.sequence
            && self.setup == request.setup
            && self.batches.iter().all(|(key, loaded)| {
                request.batches.get(key).is_some_and(|batch| {
                    loaded.rows_identity.ptr_eq(&Arc::downgrade(&batch.rows))
                        && loaded.charged_bytes == batch.charged_bytes
                })
            })
    }

    pub(super) fn batch_count(&self) -> usize {
        self.batches.len()
    }
}

fn charge(current: usize, additional: usize) -> Result<usize> {
    let total = current
        .checked_add(additional)
        .context("resident input accounting overflow")?;
    ensure!(
        total <= MAX_QUERY_INPUT_BYTES,
        "DuckDB resident logical input and batch metadata exceeds 128 MiB"
    );
    Ok(total)
}

impl Worker {
    pub(super) fn install_resident(
        &mut self,
        request: ResidentRequest<'_>,
        options: &QueryOptions,
        deadline: Instant,
        cancelled: &AtomicBool,
    ) -> Result<QueryWorkerStats> {
        self.resident_attempted = true;
        let full = self.resident.is_none();
        let mut state = self.resident.take().unwrap_or_else(|| ResidentState {
            namespace: request.snapshot.namespace.clone(),
            sequence: request.snapshot.sequence,
            setup: request.setup.clone(),
            batches: BTreeMap::new(),
            dynamic: vec![],
            rows: 0,
            bytes: 0,
        });
        ensure!(state.compatible(&request), "incompatible resident worker");
        let mut dynamic = Vec::new();
        for table in request.tables {
            check_deadline(deadline, cancelled)?;
            append_table_input(&mut dynamic, table)?;
        }
        for relation in &request.catalog.relations {
            check_deadline(deadline, cancelled)?;
            append_catalog_input(&mut dynamic, relation)?;
        }
        let changed = state.dynamic != dynamic;
        let mut bytes = charge(request.metadata_bytes, dynamic.len())?;
        let mut rows = 0_usize;
        let mut raw = Vec::new();
        let mut additions = 0;
        let mut staged_rows = 0_u64;
        for (key, batch) in &request.batches {
            check_deadline(deadline, cancelled)?;
            if !state.batches.contains_key(key) {
                charge(bytes, batch.charged_bytes)?;
                let cutoff = request
                    .tables
                    .iter()
                    .find(|table| table.name == key.0)
                    .expect("validated table")
                    .cutoff_us;
                let start = raw.len();
                let mut logical = 0_usize;
                let mut count = 0;
                for row in batch.rows.iter() {
                    check_deadline(deadline, cancelled)?;
                    if cutoff.is_some_and(|cutoff| row.row.timestamp_us < cutoff) {
                        continue;
                    }
                    row.row.validate().context("validate resident query row")?;
                    logical = charge(logical, row.row.estimated_bytes().saturating_add(16))?;
                    append_json_line(
                        &mut raw,
                        &HotInput {
                            kind: "hot",
                            table_name: &key.0,
                            timestamp_us: row.row.timestamp_us,
                            tenant: &row.row.tenant,
                            series: &row.row.series,
                            value: row.row.value,
                            tags: serde_json::to_string(&row.row.tags)?,
                            sequence: row.sequence,
                            ordinal: row.ordinal,
                        },
                    )?;
                    count += 1;
                }
                let batch_bytes = logical.max(raw.len() - start).max(batch.charged_bytes);
                state.batches.insert(
                    key.clone(),
                    LoadedBatch {
                        rows_identity: Arc::downgrade(&batch.rows),
                        rows: count,
                        bytes: batch_bytes,
                        charged_bytes: batch.charged_bytes,
                    },
                );
                additions += 1;
                staged_rows = staged_rows.saturating_add(count as u64);
            }
            let loaded = &state.batches[key];
            bytes = charge(bytes, loaded.bytes)?;
            rows = rows
                .checked_add(loaded.rows)
                .context("resident row count overflow")?;
        }
        let staged_bytes = raw.len() as u64;
        if changed {
            // This includes current rollups and current catalog rows, compared as exact
            // canonical bytes (including negative zero), never float PartialEq.
            charge(raw.len(), dynamic.len())?;
            raw.extend_from_slice(&dynamic);
        }
        let mut script = self.configuration(options)?;
        script.push_str("BEGIN TRANSACTION;\n");
        if full {
            script.push_str(&request.setup);
        }
        if changed {
            script.push_str("DELETE FROM __varve_input WHERE kind <> 'hot';\n");
        }
        let input = if raw.is_empty() {
            None
        } else {
            let mut file = tempfile::Builder::new()
                .prefix("resident-")
                .suffix(".json")
                .tempfile_in(&self.inputs)
                .context("create resident input")?;
            file.write_all(&raw).context("stage resident input")?;
            file.flush().context("flush resident input")?;
            script.push_str(&format!("INSERT INTO __varve_input SELECT * FROM read_json({}, format = 'newline_delimited', auto_detect = false, columns = {{", quote_path(file.path())?));
            for (index, (name, kind)) in INPUT_COLUMNS.iter().enumerate() {
                if index > 0 {
                    script.push(',');
                }
                script.push_str(&format!(
                    "{}: {}",
                    quote_identifier(name),
                    quote_literal(kind)
                ));
            }
            script.push_str("});\n");
            Some(file)
        };
        script.push_str("COMMIT;\n");
        ensure!(
            script.len() <= MAX_QUERY_SCRIPT_BYTES,
            "resident SQL script exceeds limit"
        );
        // No per-request DDL or adapter transaction is needed on an exact hit.
        if full || additions != 0 || changed {
            ensure!(
                self.run(script, deadline, cancelled, 0)?.is_empty(),
                "unexpected resident setup output"
            );
        }
        if let Some(input) = input {
            input.close().context("remove resident input")?;
        }
        check_deadline(deadline, cancelled)?;
        state.sequence = request.snapshot.sequence;
        state.dynamic = dynamic;
        state.rows = rows;
        state.bytes = bytes;
        self.resident = Some(state);
        // Count only installations acknowledged and cleaned up by the adapter;
        // later SQL/reset failures do not undo this accepted-work observation.
        Ok(QueryWorkerStats {
            resident_full_loads: u64::from(full),
            resident_delta_loads: u64::from(!full && additions != 0),
            resident_hits: u64::from(!full && additions == 0),
            resident_raw_staged_rows: staged_rows,
            resident_raw_staged_bytes: staged_bytes,
            ..QueryWorkerStats::default()
        })
    }

    pub(super) fn configuration(&self, options: &QueryOptions) -> Result<String> {
        let mut script = String::new();
        if !self.initialized {
            let paths = self
                .key
                .files
                .iter()
                .map(|file| quote_path(file))
                .collect::<Result<Vec<_>>>()?;
            script.push_str(&format!("SET memory_limit = '{}MB'; SET threads = {}; SET max_temp_directory_size = '0B'; SET preserve_insertion_order = false; ", options.memory_mb, options.threads));
            script.push_str("SET autoinstall_known_extensions = false; SET autoload_known_extensions = false; SET allow_community_extensions = false; SET allow_unsigned_extensions = false; ");
            script.push_str(&format!("SET allowed_directories = [{}]; SET allowed_paths = [{}]; SET home_directory = {}; SET temp_directory = {}; SET enable_external_access = false; SET lock_configuration = true;\n", quote_path(&self.inputs)?, paths.join(","), quote_path(self.directory.path())?, quote_path(self.directory.path())?));
        }
        Ok(script)
    }
}

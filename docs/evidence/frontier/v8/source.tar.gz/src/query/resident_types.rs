use crate::model::StoredRow;
use std::sync::Arc;

/// Immutable process-local identity. Reusing an ID for different bytes is forbidden.
#[derive(Clone, Debug)]
pub(crate) struct ResidentBatch {
    pub id: String,
    pub rows: Arc<Vec<StoredRow>>,
    pub charged_bytes: usize,
}

#[derive(Clone, Debug)]
pub(crate) struct ResidentTable {
    pub name: String,
    pub batches: Vec<ResidentBatch>,
}

/// Query input cache identity, never an acknowledgement or a durable frontier.
#[derive(Clone, Debug)]
pub(crate) struct ResidentSnapshot {
    pub namespace: String,
    pub sequence: u64,
    pub tables: Vec<ResidentTable>,
}

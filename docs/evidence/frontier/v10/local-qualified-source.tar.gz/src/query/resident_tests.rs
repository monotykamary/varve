use super::*;

#[cfg(unix)]
#[path = "resident_process_tests.rs"]
mod process;

fn options() -> QueryOptions {
    QueryOptions {
        executable: PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(".tools/duckdb"),
        timeout_ms: 5_000,
        ..QueryOptions::default()
    }
}

fn fixture(n: usize) -> (Vec<QueryTable>, ResidentSnapshot) {
    let rows = (0..n)
        .map(|i| StoredRow {
            row: crate::model::Row {
                timestamp_us: i as i64,
                tenant: "t'雪\\\n.shell echo no".into(),
                series: "s\"'); SELECT error('injected');--".into(),
                value: i as f64,
                tags: BTreeMap::from([("quote'雪".into(), "\t\\\"".into())]),
            },
            sequence: u64::MAX,
            ordinal: i as u32,
        })
        .collect();
    (
        vec![QueryTable {
            name: "metrics".into(),
            hot: vec![],
            files: vec![],
            rollups: vec![],
            cutoff_us: None,
        }],
        ResidentSnapshot {
            namespace: "db1".into(),
            sequence: 1,
            tables: vec![ResidentTable {
                name: "metrics".into(),
                batches: vec![ResidentBatch::new("batch1".into(), Arc::new(rows), 0)],
            }],
        },
    )
}

fn run(
    runtime: &QueryRuntime,
    tables: &[QueryTable],
    snapshot: &ResidentSnapshot,
    sql: &str,
    catalog: &QueryCatalog,
) -> Value {
    runtime
        .execute_resident_with_catalog(tables, snapshot, sql, &options(), catalog)
        .unwrap()
}

fn oracle(
    tables: &[QueryTable],
    snapshot: &ResidentSnapshot,
    sql: &str,
    catalog: &QueryCatalog,
) -> Value {
    let mut tables = tables.to_vec();
    for table in &mut tables {
        table.hot = snapshot
            .tables
            .iter()
            .find(|resident| resident.name == table.name)
            .unwrap()
            .batches
            .iter()
            .flat_map(|batch| batch.rows.iter().cloned())
            .collect();
    }
    execute_with_catalog(&tables, sql, &options(), catalog).unwrap()
}

#[test]
fn retained_large_snapshot_hit_delta_and_reusable_schema() {
    let runtime = QueryRuntime::new(1);
    let (tables, mut snapshot) = fixture(130);
    let catalog = QueryCatalog::default();
    let sql = "SELECT count(*) AS n, sum(value) AS total FROM metrics";
    assert_eq!(
        run(&runtime, &tables, &snapshot, sql, &catalog),
        oracle(&tables, &snapshot, sql, &catalog)
    );
    let first = runtime.stats();
    assert_eq!(
        (first.resident_full_loads, first.resident_raw_staged_rows),
        (1, 130)
    );
    assert!(first.resident_raw_staged_bytes > 0);
    let table_oid = run(
        &runtime,
        &tables,
        &snapshot,
        "SELECT table_oid FROM duckdb_tables() WHERE table_name = '__varve_input'",
        &catalog,
    );
    let pool = runtime.pool.lock().unwrap();
    let worker = &pool.idle[0];
    assert_eq!(std::fs::read_dir(&worker.inputs).unwrap().count(), 0);
    drop(pool);
    assert_eq!(
        run(&runtime, &tables, &snapshot, sql, &catalog),
        oracle(&tables, &snapshot, sql, &catalog)
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT table_oid FROM duckdb_tables() WHERE table_name = '__varve_input'",
            &catalog
        ),
        table_oid
    );
    let repeated = runtime.stats();
    assert_eq!(
        repeated.resident_raw_staged_bytes,
        first.resident_raw_staged_bytes
    );
    assert_eq!(repeated.resident_raw_staged_rows, 130);
    assert_eq!(repeated.resident_hits, 3);
    let (_, delta) = fixture(2);
    let mut batch = delta.tables[0].batches[0].clone();
    batch.id = "delta".into();
    snapshot.tables[0].batches.push(batch);
    snapshot.sequence = 2;
    assert_eq!(
        run(&runtime, &tables, &snapshot, sql, &catalog),
        oracle(&tables, &snapshot, sql, &catalog)
    );
    let appended = runtime.stats();
    assert_eq!(appended.resident_delta_loads, 1);
    assert_eq!(appended.resident_raw_staged_rows, 132);
    assert_eq!(appended.resident_idle_rows, 132);
    assert!(
        appended.resident_raw_staged_bytes - first.resident_raw_staged_bytes
            < first.resident_raw_staged_bytes
    );
    assert!(appended.resident_idle_bytes <= MAX_QUERY_INPUT_BYTES);
}

#[test]
fn retained_inversion_namespace_removal_remap_cutoff_and_table_scope_rebuild() {
    let runtime = QueryRuntime::new(1);
    let (mut tables, mut snapshot) = fixture(3);
    let catalog = QueryCatalog::default();
    let sql = "SELECT count(*) AS n FROM metrics";
    run(&runtime, &tables, &snapshot, sql, &catalog);
    for case in 0..6 {
        match case {
            0 => snapshot.sequence = 0,
            1 => snapshot.namespace = "db2".into(),
            2 => {
                snapshot.tables[0].batches[0].rows =
                    Arc::new(vec![snapshot.tables[0].batches[0].rows[0].clone()]);
            }
            3 => tables[0].cutoff_us = Some(1),
            4 => snapshot.tables[0].batches.clear(),
            5 => {
                tables[0].name = "renamed".into();
                snapshot.tables[0].name = "renamed".into();
            }
            _ => unreachable!(),
        }
        let sql = sql.replace("metrics", &tables[0].name);
        assert_eq!(
            run(&runtime, &tables, &snapshot, &sql, &catalog),
            oracle(&tables, &snapshot, &sql, &catalog)
        );
        assert_eq!(runtime.stats().resident_full_loads, case + 2);
        assert_eq!(runtime.stats().resident_invalidations, case + 1);
    }
}

#[test]
fn retained_exact_numeric_unicode_catalog_and_independent_rollup_freshness() {
    let runtime = QueryRuntime::new(1);
    let (mut tables, mut snapshot) = fixture(136);
    let numbers = [
        -0.0,
        0.0,
        f64::from_bits(1),
        -f64::from_bits(1),
        f64::MIN_POSITIVE,
        f64::MAX,
        -f64::MAX,
        1.0 / 3.0,
    ];
    for (i, row) in Arc::get_mut(&mut snapshot.tables[0].batches[0].rows)
        .unwrap()
        .iter_mut()
        .enumerate()
    {
        row.row.value = numbers[i % numbers.len()];
        row.row.timestamp_us = if i % 2 == 0 { i64::MIN } else { i64::MAX };
        row.sequence = if i % 2 == 0 { 0 } else { u64::MAX };
        row.ordinal = u32::MAX - i as u32;
    }
    let mut catalog = QueryCatalog {
        relations: vec![CatalogRelation {
            name: "metadata".into(),
            columns: vec![
                ("number".into(), "DOUBLE".into()),
                ("text".into(), "VARCHAR".into()),
            ],
            rows: vec![json!([-0.0, "quotes'雪\0"])],
        }],
        aggregates: vec![AggregateAlias {
            name: "minute \"雪".into(),
            source: "metrics".into(),
            width_us: 1,
        }],
    };
    tables[0].rollups =
        vec![RollupRow::from_row(1, &snapshot.tables[0].batches[0].rows[0]).unwrap()];
    let sql = "SELECT * FROM metrics ORDER BY ordinal DESC";
    let result = run(&runtime, &tables, &snapshot, sql, &catalog);
    assert_eq!(result, oracle(&tables, &snapshot, sql, &catalog));
    for (i, row) in result.as_array().unwrap().iter().enumerate() {
        assert_eq!(
            row["value"].as_f64().unwrap().to_bits(),
            numbers[i % numbers.len()].to_bits()
        );
    }
    let staged = runtime.stats().resident_raw_staged_bytes;
    for number in [-0.0, 0.0, -0.0] {
        catalog.relations[0].rows = vec![json!([number, "current\0雪"])];
        tables[0].rollups[0].sum = number;
        let sql = "SELECT sum, number, text FROM \"minute \"\"雪\" CROSS JOIN metadata()";
        let result = run(&runtime, &tables, &snapshot, sql, &catalog);
        assert_eq!(result, oracle(&tables, &snapshot, sql, &catalog));
        assert_eq!(
            result[0]["number"].as_f64().unwrap().to_bits(),
            number.to_bits()
        );
        assert_eq!(
            result[0]["sum"].as_f64().unwrap().to_bits(),
            number.to_bits()
        );
        assert_eq!(runtime.stats().resident_raw_staged_bytes, staged);
    }
    tables[0].cutoff_us = Some(i64::MAX);
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT count(*) AS n FROM metrics",
            &catalog
        )[0]["n"],
        68
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT count(*) AS n FROM __varve_input WHERE kind = 'hot'",
            &catalog
        )[0]["n"],
        68
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT count FROM metrics__rollup",
            &catalog
        )[0]["count"],
        "1"
    );
    // Current empty nonraw sets replace old rows without evicting raw.
    tables[0].rollups.clear();
    catalog.relations[0].rows.clear();
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT * FROM metrics__rollup",
            &catalog
        ),
        json!([])
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT * FROM metadata()",
            &catalog
        ),
        json!([])
    );
}

#[test]
fn acknowledged_dynamic_counters_include_empty_replacement_with_zero_bytes() {
    let runtime = QueryRuntime::new(1);
    let (tables, snapshot) = fixture(0);
    let mut catalog = QueryCatalog {
        relations: vec![CatalogRelation {
            name: "metadata".into(),
            columns: vec![("value".into(), "BIGINT".into())],
            rows: vec![json!([7])],
        }],
        aggregates: vec![],
    };
    let sql = "SELECT value FROM metadata()";
    assert_eq!(
        run(&runtime, &tables, &snapshot, sql, &catalog),
        json!([{"value": 7}])
    );
    let loaded = runtime.stats();
    assert_eq!(loaded.resident_dynamic_loads, 1);
    assert!(loaded.resident_dynamic_staged_bytes > 0);

    assert_eq!(
        run(&runtime, &tables, &snapshot, sql, &catalog),
        json!([{"value": 7}])
    );
    let hit = runtime.stats();
    assert_eq!(hit.resident_dynamic_loads, loaded.resident_dynamic_loads);
    assert_eq!(
        hit.resident_dynamic_staged_bytes,
        loaded.resident_dynamic_staged_bytes
    );

    catalog.relations[0].rows.clear();
    assert_eq!(run(&runtime, &tables, &snapshot, sql, &catalog), json!([]));
    let emptied = runtime.stats();
    assert_eq!(
        emptied.resident_dynamic_loads,
        hit.resident_dynamic_loads + 1
    );
    assert_eq!(
        emptied.resident_dynamic_staged_bytes,
        hit.resident_dynamic_staged_bytes
    );
}

#[test]
fn retained_fresh_only_sql_never_acquires_future_or_historical_raw() {
    let runtime = QueryRuntime::new(2);
    let (tables, mut snapshot) = fixture(130);
    snapshot.sequence = 2;
    run(
        &runtime,
        &tables,
        &snapshot,
        "SELECT count(*) FROM metrics",
        &QueryCatalog::default(),
    );
    let mut older = snapshot.clone();
    older.sequence = 1;
    older.tables[0].batches.clear();
    assert_eq!(
        run(
            &runtime,
            &tables,
            &older,
            "SELECT * FROM query('SELECT count(*) AS n FROM __varve_input WHERE kind = ''hot''')",
            &QueryCatalog::default()
        )[0]["n"],
        0
    );
    assert_eq!(
        (
            runtime.stats().spawned,
            runtime.stats().reused,
            runtime.stats().idle
        ),
        (2, 0, 1)
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT count(*) AS n FROM metrics",
            &QueryCatalog::default()
        )[0]["n"],
        130
    );
}

#[test]
fn retained_total_not_delta_and_empty_batch_metadata_are_bounded() {
    assert!(charge(MAX_QUERY_INPUT_BYTES, 1).is_err());
    assert!(charge(0, usize::MAX).is_err());
    let runtime = QueryRuntime::new(1);
    let (tables, mut snapshot) = fixture(1);
    snapshot.tables[0].batches[0].charged_bytes = MAX_QUERY_INPUT_BYTES / 2;
    run(
        &runtime,
        &tables,
        &snapshot,
        "SELECT count(*) FROM metrics",
        &QueryCatalog::default(),
    );
    let mut delta = snapshot.tables[0].batches[0].clone();
    delta.id = "another".into();
    snapshot.tables[0].batches.push(delta);
    let error = runtime
        .execute_resident_with_catalog(
            &tables,
            &snapshot,
            "SELECT count(*) FROM metrics",
            &options(),
            &QueryCatalog::default(),
        )
        .unwrap_err();
    assert!(
        error.to_string().contains("resident logical input"),
        "{error:#}"
    );
    assert_eq!(runtime.stats().idle, 0);
    assert_eq!(runtime.stats().resident_raw_staged_rows, 1);
    snapshot.tables[0].batches[0].rows = Arc::new(vec![]);
    snapshot.tables[0].batches.truncate(1);
    snapshot.tables[0].batches[0].charged_bytes = MAX_QUERY_INPUT_BYTES;
    assert!(
        runtime
            .execute_resident_with_catalog(
                &tables,
                &snapshot,
                "SELECT 1",
                &options(),
                &QueryCatalog::default()
            )
            .is_err()
    );
    snapshot.tables[0].batches[0].charged_bytes = 0;
    let duplicate = snapshot.tables[0].batches[0].clone();
    snapshot.tables[0].batches.push(duplicate);
    assert!(
        runtime
            .execute_resident_with_catalog(
                &tables,
                &snapshot,
                "SELECT 1",
                &options(),
                &QueryCatalog::default()
            )
            .unwrap_err()
            .to_string()
            .contains("duplicate")
    );
}

#[test]
fn retained_remapped_negative_zero_and_invalid_nul_fail_closed() {
    let runtime = QueryRuntime::new(1);
    let (tables, mut snapshot) = fixture(1);
    let catalog = QueryCatalog::default();
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT value FROM metrics",
            &catalog
        )[0]["value"]
            .as_f64()
            .unwrap()
            .to_bits(),
        0.0_f64.to_bits()
    );
    let mut row = snapshot.tables[0].batches[0].rows[0].clone();
    row.row.value = -0.0;
    snapshot.tables[0].batches[0].rows = Arc::new(vec![row.clone()]);
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT value FROM metrics",
            &catalog
        )[0]["value"]
            .as_f64()
            .unwrap()
            .to_bits(),
        (-0.0_f64).to_bits()
    );
    assert_eq!(runtime.stats().resident_full_loads, 2);
    row.row
        .tags
        .insert("invalid".into(), "contains\0NUL".into());
    snapshot.tables[0].batches[0].rows = Arc::new(vec![row]);
    assert!(
        runtime
            .execute_resident_with_catalog(
                &tables,
                &snapshot,
                "SELECT value FROM metrics",
                &options(),
                &catalog
            )
            .is_err()
    );
    assert_eq!(runtime.stats().idle, 0);
}

#[test]
fn retained_errors_output_and_cancellation_discard_partial_state() {
    let runtime = QueryRuntime::new(1);
    let (tables, snapshot) = fixture(130);
    let catalog = QueryCatalog::default();
    for sql in [
        "SELECT error('expected')",
        "SELECT no_such_column FROM metrics",
    ] {
        assert!(
            runtime
                .execute_resident_with_catalog(&tables, &snapshot, sql, &options(), &catalog)
                .is_err()
        );
        assert_eq!(runtime.stats().idle, 0);
    }
    let mut bounded = options();
    bounded.max_output_bytes = 8;
    assert!(
        runtime
            .execute_resident_with_catalog(
                &tables,
                &snapshot,
                "SELECT * FROM metrics",
                &bounded,
                &catalog
            )
            .unwrap_err()
            .to_string()
            .contains("output exceeded")
    );
    assert_eq!(runtime.stats().idle, 0);
    assert!(
        runtime
            .execute_resident_with_catalog_cancellable(
                &tables,
                &snapshot,
                "SELECT 1",
                &options(),
                &catalog,
                &AtomicBool::new(true)
            )
            .unwrap_err()
            .to_string()
            .contains("cancelled")
    );
    assert_eq!(
        run(
            &runtime,
            &tables,
            &snapshot,
            "SELECT count(*) AS n FROM metrics -- trailing comment",
            &catalog
        )[0]["n"],
        130
    );
    assert_eq!(runtime.stats().resident_invalidations, 3);
}
